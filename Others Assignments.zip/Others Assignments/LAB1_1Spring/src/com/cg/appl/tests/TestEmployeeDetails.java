package com.cg.appl.tests;

import org.springframework.context.ApplicationContext;

import com.cg.appl.entities.Employee;
import com.cg.appl.util.SpringUtil;

public class TestEmployeeDetails {

	public static void main(String[] args) {
		SpringUtil util=new SpringUtil();
		ApplicationContext ctx=util.getSpringContext();
		
		Employee employee=ctx.getBean("employeeDetails", Employee.class);
		
		System.out.println(employee.getEmployeeId());
		System.out.println(employee.getEmployeeName());
		System.out.println(employee.getSalary());
		System.out.println(employee.getBusinessUnit());
		System.out.println(employee.getAge());
		
	}
	
	
	}


