package com.cg.appl.servlets;

import java.io.IOException;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder.In;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.appl.Services.UserMasterServices;
import com.cg.appl.Services.UserMasterServicesImpl;
import com.cg.appl.UserException.UsersException;
import com.cg.appl.entities.BillDetails;
import com.cg.appl.entities.Consumers;
import com.cg.appl.entities.User;

@WebServlet("*.do")
public class FrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserMasterServices service;
	private RequestDispatcher requestDispatcher;
	private String nextJspString;
	String msg = null;
	private ServletContext ctxContext;

	public void init() throws ServletException {
		ctxContext = super.getServletContext();
		service = (UserMasterServices) ctxContext.getAttribute("services");
	}

	private void processRequest(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String command = request.getServletPath();
		System.out.println(command);

		switch (command) {
		case "/login.do": {
			nextJspString = "/login.jsp";
		}
			break;
		case "/index.do": {
			nextJspString = "/index.jsp";
		}
			break;
		case "/search.do": {
			String cnuString = request.getParameter("cnumber");
			int cnmuber = Integer.parseInt(cnuString);

			try {
				Consumers consumers = service.getConsumers(cnmuber);
				System.out.println(consumers);
				if (consumers == null) {

					msg = "Error occured:\n No bill details for customer number: "+cnmuber;
					request.setAttribute("errorMsg", msg);
					nextJspString = "/error.jsp";
					// ctxContext.log(e, msg);
					
				}
				else {
					
					request.setAttribute("consum", consumers);
					nextJspString = "/consumer.jsp";
				}

			} catch (UsersException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		
		}
			break;

		case "/searchfirst.do": {
			nextJspString = "/search.jsp";
		}
			break;

		case "/authenticate.do": {
			String uString = request.getParameter("userName");
			String password = request.getParameter("password");

			try {

				boolean isAuthenticated = service.isUserAuthenticated(uString,
						password);

				if (isAuthenticated) {
					ctxContext.log("AUTHENTICATE" + uString);
					// ///////////////////////////////////////////////////
					// starting session
					User user = service.getUserDetails(uString);
					HttpSession session = request.getSession(true);
					System.out.println(session.getId());
					session.setAttribute("users", user.getUserName());

					// ///////////////////////////////////////////////////
					nextJspString = "/mainMenu.jsp";
				} else {
					System.out.println("NO");
					/*
					 * dispatcher = request.getRequestDispatcher("/login.jsp");
					 * dispatcher.forward(request, resp);
					 */
					msg = "Wrong Credential...Enter Again";
					request.setAttribute("errorMsg", msg);
					nextJspString = "/login.jsp";
				}

			} catch (UsersException e) {
				/*
				 * dispatcher = request.getRequestDispatcher("/error.jsp");
				 * dispatcher.forward(request, resp);
				 */
				msg = "User Name doest not exist";
				request.setAttribute("errorMsg", msg);
				nextJspString = "/error.jsp";
				// ctxContext.log(e, msg);
				ctxContext.log(e.getMessage());
				// TODO Auto-generated catch block
				// e.printStackTrace();
			}
		}
			break;

		case "/logout.do": {
			try {
				HttpSession session = request.getSession(false);
				session.invalidate();// destroys session
			} catch (Exception e) {
			}
			nextJspString = "/login.jsp";

		}
			break;

		case "/consumershow.do": {
			try {
				List<Consumers> list;
				list = service.getConsumers();
				request.setAttribute("listconsum", list);
				nextJspString = "/bill.jsp";
			} catch (UsersException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
			break;

		case "/listbill.do": {

			List<BillDetails> list;
			String idString = (String) request.getParameter("id");
			int consumer_num = Integer.parseInt(idString);
			try {
				list = service.getBillDetails(consumer_num);
				request.setAttribute("list", list);
				nextJspString = "/showall.jsp";
			} catch (UsersException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
			break;

		case "/consumer.do": {
			String idString = (String) request.getParameter("id");
			int consumer_num = Integer.parseInt(idString);
			String consumer_name = request.getParameter("name");
			String address = request.getParameter("address");
			Consumers consumers = new Consumers(consumer_num, consumer_name,
					address);
			request.setAttribute("consum", consumers);
			nextJspString = "/consumer.jsp";

		}
			break;

		case "/cal.do": {
			// HttpSession session = request.getSession(false);
			try {
				// String users = (String) session.getAttribute("users");
				// System.out.println("xxxxxx" + users);

				String consumer_num1 = request.getParameter("number");
				String cur_reading1 = request.getParameter("current");
				String lastreading1 = request.getParameter("last");

				int consumer_num = Integer.parseInt(consumer_num1);
				double cur_reading = Double.parseDouble(cur_reading1);
				double lastreading = Double.parseDouble(lastreading1);

				BillDetails b = new BillDetails(consumer_num, cur_reading);
				try {
					if (service.consumer(b, lastreading)) {
						request.setAttribute("consumer", b);
						nextJspString = "/data.jsp";

					} else {

						msg = "CURRENT MONTH READING CAN NOT BE LESS THAN PREVIOUS MONTH READING";
						request.setAttribute("errorMsg", msg);
						nextJspString = "/error.jsp";
						// ctxContext.log(e, msg);

					}
				} catch (UsersException e) {

					msg = e.getMessage();
					request.setAttribute("errorMsg", msg);
					nextJspString = "/error.jsp";
					// ctxContext.log(e, msg);
					ctxContext.log(e.getMessage());
				}

			} catch (Exception e) {
				msg = "NOT LOGIN..PLEASE LOGIN";
				request.setAttribute("errorMsg", msg);
				nextJspString = "/error.jsp";
				// ctxContext.log(e, msg);
				// e.printStackTrace();
				ctxContext.log(e.getMessage());
			}
		}
			break;
		}
		requestDispatcher = request.getRequestDispatcher(nextJspString);
		requestDispatcher.forward(request, response);

	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	public void destroy() {
		service = null;
	}

}
