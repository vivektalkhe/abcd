package com.cg.appl.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.appl.UserException.UsersException;
import com.cg.appl.entities.BillDetails;
import com.cg.appl.entities.Consumers;
import com.cg.appl.entities.User;
import com.cg.appl.util.*;

public class UserMasterDaoImpl implements UserMasterDao {
	private JndiUtil jdbcUtill = null;

	public UserMasterDaoImpl() throws UsersException {
		// jdbcUtill=new JdbcUtill();
		jdbcUtill = new JndiUtil();
	}

	@Override
	public User getUserDetails(String userName) throws UsersException {
		PreparedStatement stat = null;
		Connection connection = null;
		ResultSet rs = null;

		String Query = "select username,password,userfname from usermaster where username=? ";
		try {

			connection = jdbcUtill.getConnection();
			stat = connection.prepareStatement(Query);
			stat.setString(1, userName);
			rs = stat.executeQuery();
			if (rs.next()) {
				String Password = rs.getString("password");
				String userfname = rs.getString("userfname");
				User usrUser = new User(userName, Password, userfname);
				return usrUser;
			} else {
				throw new UsersException("Wrong user Name");
			}

		} catch (SQLException e) {
			throw new UsersException("JDBC FAILED");
		} finally {
			if (rs != null) {
				try {
					rs.close();
					if (stat != null) {
						stat.close();
					}
					if (connection != null) {
						connection.close();
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					// e.printStackTrace();
					throw new UsersException("Connection Closing failed");
				}
			}

		}
	}

	@Override
	public boolean consumer(BillDetails b, double lastmonth)
			throws UsersException {

		PreparedStatement stat = null;
		Connection connection = null;
		ResultSet rs = null;

		String Query = "insert into BillDetails values(seq_bill_num.nextval,?,?,?,?,sysdate) ";
		try {
			double amount = UserMasterDaoImpl.UnitConsumed(lastmonth,
					b.getCur_reading());
			if(amount==0.0)
			{
				return false;
			}
			else{
			b.setNetAmount(amount);
			b.setUnitConsumed(b.getCur_reading()-lastmonth);

			connection = jdbcUtill.getConnection();
			stat = connection.prepareStatement(Query);
			stat.setInt(1, b.getConsumer_num());
			stat.setInt(2,(int) b.getCur_reading());
			stat.setInt(3,(int) b.getUnitConsumed());
			stat.setInt(4,(int) b.getNetAmount());
			rs = stat.executeQuery();
			if (rs.next()) {
				
				return true;
			} else {
				
				return false;
			}
			}
		} catch (SQLException e) {
		//	throw new UserException("JDBC FAILED");
			throw new UsersException("USER NOT FOUND");		}

	}

	public static double UnitConsumed(double lastmonth, double currentmonth) throws UsersException {
		double totalcon = currentmonth - lastmonth;
		if(totalcon<0)
		{
			throw new UsersException("CURRENT MONTH READING CAN NOT BE LESS THAN PREVIOUS MONTH READING");
		}
		double netamount = totalcon * 1.15 + 100;
		return netamount;

	}

	@Override
	public List<Consumers> getConsumers() throws UsersException {
		

		// /////////////////////////////////////////
		List<Consumers> list = new ArrayList<Consumers>();
		PreparedStatement stat = null;
		Connection connection = null;
		ResultSet rs = null;
		Consumers consumers = null;
		String Query = "select * from Consumers ";
		try {
			connection = jdbcUtill.getConnection();
			stat = connection.prepareStatement(Query);
			rs = stat.executeQuery();
			while (rs.next()) {

				Integer consumer_num = rs.getInt("consumer_num");
				String consumer_name = rs.getString("consumer_name");
				String address = rs.getString("address");
			 consumers=new Consumers(consumer_num, consumer_name, address);
				list.add(consumers);
			}
			return list;

		} catch (SQLException e) {
			throw new UsersException(" PROBLEM IN FETCHING ");
		}
	}

	@Override
	public List<BillDetails> getBillDetails(int consumer_num) throws UsersException {
		

		// /////////////////////////////////////////
		List<BillDetails> list = new ArrayList<BillDetails>();
		PreparedStatement stat = null;
		Connection connection = null;
		ResultSet rs = null;
		Consumers consumers = null;
		String Query = "select * from BillDetails where consumer_num=? ";
		try {
			connection = jdbcUtill.getConnection();
			stat = connection.prepareStatement(Query);
			stat.setInt(1, consumer_num);
			rs = stat.executeQuery();
			while (rs.next()) {

				Integer bill_num = rs.getInt("bill_num");
				 consumer_num = rs.getInt("consumer_num");
				Integer cur_reading = rs.getInt("cur_reading");
				Integer unitConsumed = rs.getInt("unitConsumed");
				Integer netAmount = rs.getInt("netAmount");
				java.sql.Date bill_date = rs.getDate("bill_date");
				
		
				BillDetails billDetails=new BillDetails(bill_num, consumer_num,(double) cur_reading, (double)unitConsumed,(double) netAmount, bill_date);
			list.add(billDetails);
			}
			return list;

		} catch (SQLException e) {
			throw new UsersException(" PROBLEM IN FETCHING ");
		}
	}

	
	@Override
	public Consumers getConsumers(int consumer_num) throws UsersException {
	

		PreparedStatement stat = null;
		Connection connection = null;
		ResultSet rs = null;

		String Query = "select * from Consumers where consumer_num=? ";
		try {

			connection = jdbcUtill.getConnection();
			stat = connection.prepareStatement(Query);
			stat.setInt(1, consumer_num);
			rs = stat.executeQuery();
			if (rs.next()) {
				String consumer_name = rs.getString("consumer_name");
				String address = rs.getString("address");
				Consumers consumers=new Consumers(consumer_num, consumer_name, address);
				return consumers;
			} else {
				return null;
				//throw new UserException("NO CONSUMER EXISTS");
			}

		} catch (SQLException e) {
			throw new UsersException("JDBC FAILED");
		} finally {
			if (rs != null) {
				try {
					rs.close();
					if (stat != null) {
						stat.close();
					}
					if (connection != null) {
						connection.close();
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					// e.printStackTrace();
					throw new UsersException("Connection Closing failed");
				}
			}

		}

	}

}
