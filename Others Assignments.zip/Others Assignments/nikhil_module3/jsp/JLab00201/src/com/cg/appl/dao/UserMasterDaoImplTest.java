package com.cg.appl.dao;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.appl.UserException.UsersException;
import com.cg.appl.entities.BillDetails;

public class UserMasterDaoImplTest {
static BillDetails b=null;
static UserMasterDaoImpl umd=null;
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	b=new BillDetails(100001, 5000);
	umd=new UserMasterDaoImpl();
	}

	@Test
	public void testConsumer() {
		try {
			umd.consumer(b, 4000);
			assertNotNull(umd);
		} catch (UsersException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}

}
