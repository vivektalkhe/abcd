package com.cg.appl.Services;

import java.util.List;

import com.cg.appl.UserException.UsersException;
import com.cg.appl.entities.BillDetails;
import com.cg.appl.entities.Consumers;

public interface UserMasterServices {
	com.cg.appl.entities.User getUserDetails(String userName)
			throws UsersException;

	boolean isUserAuthenticated(String username, String Password)
			throws UsersException;
	
    boolean consumer(BillDetails b,double lastreading) throws UsersException;
    
    List<com.cg.appl.entities.Consumers> getConsumers() throws UsersException;
    List<BillDetails> getBillDetails(int consumer_num) throws UsersException;
    Consumers getConsumers(int consumer_num) throws UsersException;
}
