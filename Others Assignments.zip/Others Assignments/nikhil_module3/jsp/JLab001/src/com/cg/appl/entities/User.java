package com.cg.appl.entities;

import java.io.Serializable;



public class User implements Serializable {

/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
private	String userNm;
private String passwrd;
private String userFullname;
public String getUserName() {
	return userNm;
}
public void setUserName(String userName) {
	this.userNm = userName;
}
public String getPassword() {
	return passwrd;
}
public void setPassword(String password) {
	this.passwrd = password;
}
public String getUserFullname() {
	return userFullname;
}
public void setUserFullname(String userFullname) {
	this.userFullname = userFullname;
}
public User(String userName, String password, String userFullname) {
	super();
	this.userNm = userName;
	this.passwrd = password;
	this.userFullname = userFullname;
}


}
