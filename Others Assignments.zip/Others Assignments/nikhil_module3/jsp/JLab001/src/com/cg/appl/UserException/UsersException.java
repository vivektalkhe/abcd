package com.cg.appl.UserException;

public class UsersException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public UsersException() {
		// TODO Auto-generated constructor stub
	}

	public UsersException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public UsersException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public UsersException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public UsersException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
