package com.cg.appl.Services;

import com.cg.appl.UserException.UsersException;

public interface UserMasterServices {
	com.cg.appl.entities.User getUserDetails(String userName)
			throws UsersException;

	boolean isUserAuthenticated(String username, String Password)
			throws UsersException;
}
