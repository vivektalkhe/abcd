package com.cg.appl.listeners;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

import com.cg.appl.Services.UserMasterServices;
import com.cg.appl.Services.UserMasterServicesImpl;
import com.cg.appl.UserException.UsersException;

@WebListener
public class ProcureServiceListener implements ServletContextListener {

	UserMasterServices service=null;
	ServletContext ctx=null;
	public void contextInitialized(ServletContextEvent event) {
		ctx=event.getServletContext();
		try {
			service = new UserMasterServicesImpl();
			ctx.setAttribute("services", service);
		} catch (UsersException e) {
			// TODO Auto-generated catch block
			 e.printStackTrace();
		}
	}

	public ProcureServiceListener() {
	}

	public void contextDestroyed(ServletContextEvent arg0) {
		// TODO Auto-generated method stub
	}

}
