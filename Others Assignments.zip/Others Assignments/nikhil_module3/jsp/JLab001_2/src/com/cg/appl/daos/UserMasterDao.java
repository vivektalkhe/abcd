package com.cg.appl.daos;



import com.cg.appl.UserException.UsersException;
import com.cg.appl.dto.BillDetail;

public interface UserMasterDao {
	com.cg.appl.dto.User getUserDetails(String userName) throws UsersException;
    boolean consumer(BillDetail b,double lastreading) throws UsersException;
}
