package com.cg.appl.Services;

import com.cg.appl.UserException.UsersException;
import com.cg.appl.dto.BillDetail;

public interface UserMasterServices {
	com.cg.appl.dto.User getUserDetails(String userName)
			throws UsersException;

	boolean isUserAuthenticated(String username, String Password)
			throws UsersException;
	
    boolean consumer(BillDetail b,double lastreading) throws UsersException;
}
