package com.cg.appl.daos;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.appl.UserException.UsersException;
import com.cg.appl.dto.BillDetail;

public class UserMasterDaoImplTest {
static BillDetail b=null;
static UserMasterDaoImpl umd=null;
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	b=new BillDetail(100001, 5000);
	umd=new UserMasterDaoImpl();
	}

	@Test
	public void testConsumer() {
		try {
			umd.consumer(b, 4000);
			assertNotNull(umd);
		} catch (UsersException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}

}
