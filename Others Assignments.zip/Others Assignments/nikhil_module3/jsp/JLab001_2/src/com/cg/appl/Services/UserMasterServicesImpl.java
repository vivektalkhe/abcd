package com.cg.appl.Services;

import com.cg.appl.UserException.UsersException;
import com.cg.appl.daos.UserMasterDaoImpl;
import com.cg.appl.dto.BillDetail;
import com.cg.appl.dto.User;

public class UserMasterServicesImpl implements UserMasterServices {

	UserMasterDaoImpl daoImpl;
	public UserMasterServicesImpl() throws UsersException {
		 daoImpl=new UserMasterDaoImpl();	}

	@Override
	public User getUserDetails(String userName) throws UsersException {
		// TODO Auto-generated method stub
		return daoImpl.getUserDetails(userName);
	}

	@Override
	public boolean isUserAuthenticated(String username, String Password)
			throws UsersException {
		User user=daoImpl.getUserDetails(username);
		if(Password.equals(user.getPassword()))
		{
			return true;
		}
		else	return false;
	}

	@Override
	public boolean consumer(BillDetail b, double lastreading)
			throws UsersException {
		// TODO Auto-generated method stub
		return daoImpl.consumer(b, lastreading);
	}

}
