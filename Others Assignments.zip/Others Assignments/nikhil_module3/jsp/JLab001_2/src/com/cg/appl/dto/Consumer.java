package com.cg.appl.dto;

public class Consumer {
	int consumer_num;
	String Consumer_name;
	String address;
	public Consumer(int consumer_num, String consumer_name, String address) {
		super();
		this.consumer_num = consumer_num;
		this.Consumer_name = consumer_name;
		this.address = address;
	}
	public int getConsumer_num() {
		return consumer_num;
	}
	public void setConsumer_num(int consumer_num) {
		this.consumer_num = consumer_num;
	}
	public String getConsumer_name() {
		return Consumer_name;
	}
	public void setConsumer_name(String consumer_name) {
		Consumer_name = consumer_name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "Consumers [consumer_num=" + consumer_num + ", Consumer_name="
				+ Consumer_name + ", address=" + address + "]";
	}
	
}
