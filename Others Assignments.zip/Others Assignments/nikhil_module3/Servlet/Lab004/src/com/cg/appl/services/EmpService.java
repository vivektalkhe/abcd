package com.cg.appl.services;


import com.cg.appl.entities.Employee;
import com.cg.appl.exceptions.EmpException;

public interface EmpService {
	boolean addEmp(Employee e)throws EmpException;
}
