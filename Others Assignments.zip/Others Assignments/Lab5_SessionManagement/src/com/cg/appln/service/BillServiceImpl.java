package com.cg.appln.service;

import com.cg.appln.daos.BillDaoImpl;
import com.cg.appln.daos.IBillDao;
import com.cg.appln.dto.Bill;
import com.cg.appln.exception.BillException;

public class BillServiceImpl implements IBillService {
	IBillDao dao=null;
	public BillServiceImpl(){
		dao=new BillDaoImpl();
	}
	@Override
	public int insertBillDetail(Bill bill) throws BillException {
		
		return dao.insertBillDetail(bill);
	}

	@Override
	public String getConsumerName(int billNum) throws BillException {
		// TODO Auto-generated method stub
		return dao.getConsumerName(billNum);
	}
	@Override
	public boolean validateCon(int consumerNo) throws BillException {
		// TODO Auto-generated method stub
		return dao.validate(consumerNo);
	}
	

}
