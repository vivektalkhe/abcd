package com.cg.appln.util;

import java.sql.Connection;
import java.sql.SQLException;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
import com.cg.appln.exception.BillException;

public class JndiUtil {
	private DataSource dataSource;
	public JndiUtil() throws BillException  {
		try {
			Context ctx= new InitialContext();
			dataSource=(DataSource)ctx.lookup("java:/OracleDS");
			
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new BillException("Failed to get jndi context", e);
		}
	}
		
		public Connection getConnection() throws SQLException {
			
				return dataSource.getConnection();	
		}

}
