package com.cg.appln.controller;

import java.io.IOException;
import java.sql.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.appln.dto.Admin;
import com.cg.appln.dto.Bill;
import com.cg.appln.exception.BillException;
import com.cg.appln.service.BillServiceImpl;
import com.cg.appln.service.IBillService;

//@WebServlet("/billController")
@WebServlet("*.do")
public class BillController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private int fixedCharge = 0;
	Bill bill;
	IBillService services = null;
	Admin admin = null;

	public BillController() {
		super();
		bill = new Bill();
		services = new BillServiceImpl();
		admin = new Admin();
	}

	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}

	public void destroy() {
		// TODO Auto-generated method stub
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	private void processRequest(HttpServletRequest request,
			HttpServletResponse response) {
		// TODO Auto-generated method stub

	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);

		String path = request.getServletPath();

		switch (path) {
		case "/isValidAdmin.do": {
			String username = request.getParameter("username");
			String password = request.getParameter("password");

			if (username.equals(admin.getName())
					&& password.equals(admin.getPass())) {

				HttpSession session = request.getSession();
				System.out.println(session.getId());
				// session.setAttribute("userAtt", user);
				try {
					response.sendRedirect("calBill.jsp");
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} else {
				System.out.println("Invalid Username or Password");
			}
		}
		break;
		case "/calculateBill.do": {
			if (request.getParameter("consumerNo").equals("")
					|| request.getParameter("lastReading").equals("")
					|| request.getParameter("currentReading").equals("")) {
			
					try {
						throw new BillException("Fill all the fields");
					} catch (BillException e) {
						// TODO Auto-generated catch block
						System.out.println();
					}
			
			} else {
				int consumerNo = Integer.parseInt(request.getParameter("consumerNo"));
				try {
					boolean status=services.validateCon(consumerNo);
					System.out.println(status);
					if(status==false){
						throw new BillException("Invalid Cunsumer Number");
					}else{
						double lastReading = Double.valueOf(request
								.getParameter("lastReading"));
						double currentReading = Double.valueOf(request
								.getParameter("currentReading"));
						double netAmount = 0, unitsConsumed;
						// Units consumed = (Last month meter reading) � (Current month
						// meter reading)
						// Net Amount = Unit consumed * 1.15 + Fixed Charge

						unitsConsumed = lastReading - currentReading;
						netAmount = (unitsConsumed * 1.15) + fixedCharge;

						bill.setConsumer_num(consumerNo);
						bill.setCur_reading(currentReading);
						bill.setUnitConsumed(unitsConsumed);
						bill.setNetAmount(netAmount);
						// bill.setBill_date();

						services.insertBillDetail(bill);
						String consumerName;
						try {
							consumerName = services.getConsumerName(consumerNo);
							request.setAttribute("conNameAtt", consumerName);
							request.setAttribute("unitsAtt", unitsConsumed);
							request.setAttribute("billDataAtt", bill);

						} catch (BillException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

						RequestDispatcher dispatch = request
								.getRequestDispatcher("showBill.jsp");
						dispatch.forward(request, response);
					}
				} catch (BillException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
					
				}

			}
		}

		}

	}

}
