package com.cg.appln.dto;

public class Admin {

	private String name;
	private String pass;
	
	public Admin() {
		super();
		this.name="Reema";
		this.pass="pass";
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPass() {
		return pass;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}
}
