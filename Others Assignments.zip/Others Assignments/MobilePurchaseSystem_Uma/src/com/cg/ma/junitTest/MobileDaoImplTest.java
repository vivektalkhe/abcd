package com.cg.ma.junitTest;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;

import com.cg.ma.Exception.MobileException;
import com.cg.ma.dao.ImobileDao;
import com.cg.ma.dao.MobileDaoImpl;

public class MobileDaoImplTest {

	ImobileDao imobile;
	@AfterClass
	public static void tearDownAfterClass() throws Exception{
		
	}
	@Before 
	public void setUp(){
		imobile= new MobileDaoImpl();
	}
	@Test
	public void showAll(){
		try {
			assertNotNull(imobile.showAll());
		} catch (MobileException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@After
	public void tearDown() throws Exception {
		imobile= null;
	}
}
