package com.cg.ma.dto;

import java.sql.Date;
import java.time.LocalDate;

public class Purchase {

	private int purchaseid;
	private String cname;
	private String mailid;
	private String phoneno;
	
	private int mobileid;
	private java.util.Date date;
	
	static int count;

	
	

	public Purchase() {
		super();
		// TODO Auto-generated constructor stub
		count++;
		this.purchaseid = count;
	}


	public Purchase( String cname, String mailid,
			String phoneno, java.util.Date utilDate, int mobileid) {
		super();
		
		count++;
		this.purchaseid = count;
		this.cname = cname;
		this.mailid = mailid;
		this.phoneno = phoneno;
		this.date =utilDate;
		this.mobileid = mobileid;
		
	}


	public int getPurchaseid() {
		return purchaseid;
	}
	public String getMailid() {
		return mailid;
	}


	public void setMailid(String mailid) {
		this.mailid = mailid;
	}


	public String getPhoneno() {
		return phoneno;
	}


	public void setPhoneno(String phoneno) {
		this.phoneno = phoneno;
	}




	public java.util.Date getDate() {
		return date;
	}


	public void setDate(java.util.Date date) {
		this.date = date;
	}


	public int getMobileid() {
		return mobileid;
	}


	public void setMobileid(int mobileid) {
		this.mobileid = mobileid;
	}


	public String getCname() {
		return cname;
	}


	public void setCname(String cname) {
		this.cname = cname;
	}
	
}
