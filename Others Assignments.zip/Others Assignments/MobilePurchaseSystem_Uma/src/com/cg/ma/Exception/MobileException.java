package com.cg.ma.Exception;

public class MobileException extends Exception{

	public MobileException(String msg) {
		super(msg);
		
	}

	
}
