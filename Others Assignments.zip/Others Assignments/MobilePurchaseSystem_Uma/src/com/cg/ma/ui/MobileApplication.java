package com.cg.ma.ui;

import java.util.Date;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.ma.Exception.MobileException;
import com.cg.ma.dto.Mobile;
import com.cg.ma.dto.Purchase;
import com.cg.ma.service.IMobileService;
import com.cg.ma.service.IPurchaseService;
import com.cg.ma.service.MobileServiceImpl;
import com.cg.ma.service.PurchaseServiceImpl;


public class MobileApplication {

	private static final Logger myLogger =  Logger.getLogger(MobileApplication.class.getName());
	public static void main(String[] args) {
		PropertyConfigurator.configure("log4j.properties");
		myLogger.info("Application Started");
		
		// TODO Auto-generated method stub
		IMobileService mobileService= new MobileServiceImpl();
		IPurchaseService purchaseService= new PurchaseServiceImpl();
		
		List<Mobile> mobileList= null;
		int mobile_id;
		int choice=0;
		do{
		printDetail();
		Scanner scr=new Scanner(System.in);
		choice=scr.nextInt();
		switch(choice){
		case 1://ADD
			//System.out.println(" Enter Employee Id");
			//int empId=scr.nextInt();
			/*String patt="^[A-Z][a-z]{2,9}$";
			System.out.println(" Enter Customer Name");
			
			String custName=scr.next();
			try {
				EmployeeServiceImpl.validateName(patt,empName);
			} catch (EmployeeException e1) {
				// TODO Auto-generated catch block
				//e1.printStackTrace();--Developer
				System.out.println(e1.getMessage());
				break;
			}*/
			System.out.println("Enter Customer Name: ");
			String cust_name=scr.next();
			System.out.println("Enter mailid: ");
			String mail_id=scr.next();
			System.out.println("Enter phone no: ");
			String phone_no=scr.next();
			System.out.println("Enter mobile id: ");
			mobile_id= scr.nextInt();
			java.util.Date today= new Date();
			
			
			Purchase purchase1=new Purchase();
			
			purchase1.setCname(cust_name);
			purchase1.setMailid(mail_id);
			purchase1.setPhoneno(phone_no);
			purchase1.setMobileid(mobile_id);
			purchase1.setDate(today);
			
			boolean rec;
			try {
				rec = purchaseService.insertPurchaseService(purchase1);
				if(rec==true){
					System.out.println("Purchase details inserted successfully");
				}else{
					System.out.println("Data Not Inserted");
					myLogger.info("Purchase details not inserted");
				}
			} catch (MobileException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
				
			}
			
			break;
		case 2://Show purchase details
			List<Purchase> puchaseList=null;
			try {
				puchaseList=purchaseService.showPurchaseDetailsService();
				for(Purchase p:puchaseList){
					System.out.println("Purchase Id: "+p.getPurchaseid()+"  ");
					System.out.println("Customer Name: "+p.getCname()+"  ");
					System.out.println("Mail Id: "+p.getMailid());
					System.out.println("Phone Num: "+p.getPhoneno());
					System.out.println("Purchase Date "+p.getDate());
					System.out.println("Mobile Id "+p.getMobileid());
					System.out.println("Mobile Id "+p.getMobileid()+"\n");
				}
			} catch (MobileException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			/*try {
				myEmp = empService.showAll();
			} catch (EmployeeException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			for (Employee emplo : myEmp) {
				System.out.println(" Id is "+emplo.getEmpId());
				System.out.println(" Name is "+emplo.getEmpName());
				System.out.println(" Department is "+emplo.getEmpDepartment());
				System.out.println(" Salary is "+emplo.getEmpSalary());
			}*/
			break;	
		case 3://show all mobiles
			
			try {
				mobileList= mobileService.showAllService();
				
				for(Mobile m:mobileList){
					System.out.println("Mobile Id: "+m.getMobileid());
					System.out.println("Mobile Name: "+m.getName());
					System.out.println("Mobile Price: "+m.getPrice());
					System.out.println("Mobile Quantity: "+m.getQuantity()+"\n");
				}
			} catch (MobileException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		case 4://Search for a mobile based on price range:
			System.out.println("Enter start price:");
			int start= scr.nextInt();
			System.out.println("Enter end price:");
			int end= scr.nextInt();
			
			try {
				mobileList= mobileService.searchByRangeService(start, end);
				System.out.println("Mobiles in the given range:");
				for(Mobile m: mobileList){
					System.out.println("Mobile Id: "+m.getMobileid());
					System.out.println("Mobile Name: "+m.getName());
					System.out.println("Mobile Price: "+m.getPrice());
					System.out.println("Mobile Quantity: "+m.getQuantity()+"\n");
				}
				
			} catch (MobileException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		
		case 5://remove mobile based on its id:
			System.out.println("Enter the id of mobile: ");
			mobile_id=  scr.nextInt();
			try {
				boolean isDelete=mobileService.deleteMobileService(mobile_id);
				if(isDelete==true){
					System.out.println("Mobile with id"+mobile_id+" is deleted successfully");
				}
			} catch (MobileException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				//throw new MobileException("No such mobile!");
			}
			break;
		
		case 6://Update Mobile Quantity
			System.out.println("Enter the id of mobile: ");
			mobile_id=  scr.nextInt();
			System.out.println("Enter quantity: ");
			int qty=  scr.nextInt();
			
			try {
				boolean isUpdate= mobileService.updateQtyService(mobile_id, qty);
				if(isUpdate==true){
					System.out.println("Updated successfully!");
				}
			} catch (MobileException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
			
		case 7:
			break;
			}	
		}while(choice!=7);
		

	}
	
	public static void printDetail(){
		System.out.println("**********");
		System.out.println("1. Add Purchase Details ");
		System.out.println("2. Show Purchase Details");
		System.out.println("3. Show All Mobiles");
		System.out.println("4. Search For Mobile");
		System.out.println("5. Remove Mobile ");
		System.out.println("6.Update Mobile Quantity");
		System.out.println("7. Exit");
		System.out.println("***********");
	}

}
