package com.cg.ma.util;
import java.io.FileInputStream;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import org.apache.log4j.Logger;


import com.cg.ma.Exception.MobileException;
public class JdbcUtil {
	static Logger myLogger =  Logger.getLogger(JdbcUtil.class.getName());
		public static Properties  loadProperties(){
			
			Properties prop1= new Properties();
			InputStream inFile= null;
			
			try {
				inFile = new FileInputStream("oracle.properties");
				prop1.load(inFile);
				myLogger.info("Driver is loaded");
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
				myLogger.info("Driver is not loaded");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally{
				if(inFile!=null){
					try {
						inFile.close();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}		
			}
			return prop1;
		}
		public static Connection getConnection()throws MobileException{
			Connection conn= null;
			Properties prop= loadProperties();
			String url=prop.getProperty("oracle.url");
			String driver= prop.getProperty("oracle.driver");
			String user= prop.getProperty("oracle.uname");
			String pass= prop.getProperty("oracle.upass");
			
			try {
				Class.forName(driver);
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw new MobileException("No driver found!");
			}
			
			try {
				conn= DriverManager.getConnection(url, user, pass);
				myLogger.info("Connected to the database");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
				myLogger.error("Not Connected");
				
			}	
			return conn;		
		}		
	}

