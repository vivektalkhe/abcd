package com.cg.ma.service;

import java.util.List;

import com.cg.ma.Exception.MobileException;
import com.cg.ma.dao.IpurchaseDao;
import com.cg.ma.dao.PurchaseDaoImp;
import com.cg.ma.dto.Purchase;

public class PurchaseServiceImpl implements IPurchaseService {

	IpurchaseDao dao= new PurchaseDaoImp();
	
	
	@Override
	public boolean insertPurchaseService(Purchase pur) throws MobileException {
		// TODO Auto-generated method stub
		return dao.insertPurchase(pur);
	}


	@Override
	public List<Purchase> showPurchaseDetailsService() throws MobileException {
		// TODO Auto-generated method stub
		return dao.showPurchaseDetails();
	}

}
