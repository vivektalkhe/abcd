package com.cg.ma.service;

import java.util.List;

import com.cg.ma.Exception.MobileException;
import com.cg.ma.dto.Mobile;

public interface IMobileService {

	// boolean insertMobileService(Mobile mobile) throws MobileException;
	 List<Mobile> showAllService() throws MobileException;
	 boolean deleteMobileService(int mobileId) throws MobileException;
	 List<Mobile> searchByRangeService(int start, int end) throws MobileException;
	 boolean updateQtyService(int mobileid, int qty) throws MobileException;
	 //public  void validateName(String patt,String name) throws MobileException;
}
