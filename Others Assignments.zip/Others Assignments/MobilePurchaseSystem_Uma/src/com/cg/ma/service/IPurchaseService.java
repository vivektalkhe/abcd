package com.cg.ma.service;

import java.util.List;

import com.cg.ma.Exception.MobileException;
import com.cg.ma.dto.Purchase;

public interface IPurchaseService {
	
	boolean insertPurchaseService(Purchase pur) throws MobileException;
	List<Purchase> showPurchaseDetailsService() throws MobileException;
}
