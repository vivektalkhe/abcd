package com.cg.ma.service;

import java.util.List;
import java.util.regex.Pattern;


import com.cg.ma.Exception.MobileException;
import com.cg.ma.dao.ImobileDao;
import com.cg.ma.dao.MobileDaoImpl;
import com.cg.ma.dto.Mobile;

public class MobileServiceImpl implements IMobileService{

	ImobileDao dao= new MobileDaoImpl();
	@Override
	public List<Mobile> showAllService() throws MobileException {
		// TODO Auto-generated method stub
		
		return dao.showAll();
	}

	@Override
	public boolean deleteMobileService(int mobileId) throws MobileException {
		// TODO Auto-generated method stub
		
		return dao.deleteMobile(mobileId);
	}

	@Override
	public List<Mobile> searchByRangeService(int start, int end)
			throws MobileException {
		// TODO Auto-generated method stub
		
		return dao.searchByRange(start, end);
	}

	@Override
	public boolean updateQtyService(int mobileid, int qty)
			throws MobileException {
		// TODO Auto-generated method stub
		return dao.updateQty(mobileid,qty);
	}
	
	/*
	@Override
	public boolean insertMobileService(Mobile mobile) throws MobileException {
		return dao.insertMobile(mobile);
	}

	public void validateName(String patt,String name) throws MobileException{
	boolean value=Pattern.matches(patt,name);
		if(!value){
			throw new MobileException("Name should be min3 max 10 First letter capital");
		}*/
		
	}
	
