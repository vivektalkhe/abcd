package com.cg.ma.dao;

import java.util.List;

import com.cg.ma.Exception.MobileException;
import com.cg.ma.dto.Purchase;

public interface IpurchaseDao {
	
	 boolean insertPurchase(Purchase pur) throws MobileException;
	 List<Purchase> showPurchaseDetails() throws MobileException;
}
