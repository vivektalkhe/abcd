package com.cg.ma.dao;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Formatter;
import java.util.List;
import java.util.Locale;
import java.util.Scanner;
import com.cg.ma.Exception.MobileException;
import com.cg.ma.dto.Mobile;
import com.cg.ma.dto.Purchase;
import com.cg.ma.util.JdbcUtil;
import java.util.Date;


public class MobileDaoImpl implements ImobileDao{

	Connection conn;
	PreparedStatement pst;
	
	List<Mobile> mobileList= new ArrayList<Mobile>();
	
	/*@Override
	public boolean insertMobile( Mobile mobile) throws MobileException {
		// TODO Auto-generated method stub
		int rec=0;
		conn= JdbcUtil.getConnection();
		String query= "INSERT INTO mobiles VALUES(?,?,?,?)";
		try {
			pst= conn.prepareStatement(query);
			int mid=mobile.getMobileid();
			pst.setInt(1,mid );		
			pst.setString(2, mobile.getName());
			pst.setDouble(3, mobile.getPrice());
			pst.setInt(4, mobile.getQuantity());

			rec= pst.executeUpdate();
			System.out.println(rec);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				conn.close();
				pst.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();

			}	
		}
		return false;
	}
	*/
	
	@Override
	public List<Mobile> showAll() throws MobileException {
		conn=JdbcUtil.getConnection();
		String query= "SELECT * FROM mobiles";
		try {
			pst=conn.prepareStatement(query);
			ResultSet rs= pst.executeQuery();
			while(rs.next()){
				int m_id= rs.getInt("mobileid"); // m for mem var
				String  m_name= rs.getString("name");
				double m_price= rs.getDouble("price");
				int m_qty= rs.getInt("quantity");
				
				Mobile mob= new Mobile();
				
				mob.setMobileid(m_id);
				mob.setName(m_name);
				mob.setPrice(m_price);
				mob.setQuantity(m_qty);
				
				mobileList.add(mob);	
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			throw new MobileException("Invalid Range");
		//throw user-defined exception
		}finally{
				try {
					conn.close();
					pst.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}	
		}
		return mobileList;
	}

	@Override
	public boolean deleteMobile(int mobileId) throws MobileException {
		// TODO Auto-generated method stub
		int rec=0;
		conn=JdbcUtil.getConnection();
		String query= "DELETE FROM mobiles WHERE mobileid= ?";
		
		try {
			pst= conn.prepareStatement(query);
			pst.setInt(1, mobileId);
			rec=pst.executeUpdate();
			if(rec>0){
				return true;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new MobileException("Invalid Range");
		}finally{
			try {
				conn.close();
				pst.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
	}
		
		return false;
	}

	@Override
	public List<Mobile> searchByRange(int start, int end) throws MobileException {
		// TODO Auto-generated method stub
		
		conn= JdbcUtil.getConnection();
		String query= "SELECT * FROM mobiles WHERE price>=? AND price<=?";
		List<Mobile> mobileList= new ArrayList<>();
		
		try {
			pst= conn.prepareStatement(query);
			pst.setInt(1, start);
			pst.setInt(2, end);
			ResultSet rs= pst.executeQuery();
			
			while(rs.next()){
				int m_id= rs.getInt("mobileid");// m for mem var
				String  m_name= rs.getString("name");
				double m_price= rs.getDouble("price");
				int m_qty= rs.getInt("quantity");
				
				Mobile mob= new Mobile();
				
				//mob.setMobileid(m_id);
				mob.setName(m_name);
				mob.setPrice(m_price);
				mob.setQuantity(m_qty);
				
				mobileList.add(mob);	
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
			throw new MobileException("Invalid Range");
		}finally{
			try {
				conn.close();
				pst.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
	}
		
		return null;
	}

	@Override
	public boolean updateQty(int mobileid, int qty) throws MobileException {
		int rec=0;
		conn= JdbcUtil.getConnection();
		if(conn!=null)
			System.out.println("conenected");
		String query= "UPDATE mobiles SET quantity=quantity-'"+qty+"' where  mobileid='"+mobileid+"'";
	
		try {
			pst= conn.prepareStatement(query);
			
			/*pst.setInt(1,qty);
			pst.setInt(2,mobileid);*/
			rec= pst.executeUpdate();
		
			if(rec>0){
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new MobileException("Data is not updated");
		}finally{
			try {
				conn.close();
				pst.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();

			}	
	}
		return false;
	}



	
/*	public static void main(String args[]){
		
		ImobileDao impl= new MobileDaoImpl();
		java.util.Date utilDate= new Date();
		
		
		Purchase pur= new Purchase("Saurabh","saurabhmhatre@gmail.com", "8237318552", utilDate,1002);
		try {
			System.out.println(impl.insertPurchase(pur));
			System.out.println("ya");
		} catch (MobileException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			//System.out.println(impl.updateQty(1002,10));

		      

			Purchase pur= new Purchase("Saurabh","saurabhmhatre@gmail.com", "8237318552", sqlDate,1002 );
			System.out.println(impl.insertPurchase(pur));
		} catch (MobileException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}*/
		/*
		for(Mobile m:mList){
			System.out.println(m);
		}
		impl.deleteMobile(1005);
		
	}*/


}
