package com.cg.ma.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.cg.ma.Exception.MobileException;
import com.cg.ma.dto.Purchase;
import com.cg.ma.util.JdbcUtil;

public class PurchaseDaoImp implements IpurchaseDao {

	Connection conn;
	PreparedStatement pst;
	List<Purchase> puchaseList= new ArrayList<Purchase>();
	
	@Override
	public boolean insertPurchase(Purchase pur) throws MobileException {
		int rec=0;
		int purId=0;
		int mobId=0; 
		int qty = 0;
		
		conn= JdbcUtil.getConnection();
		String query= "INSERT INTO purchasedetails VALUES(?,?,?,?,sysdate,?)";
		try {
			pst= conn.prepareStatement(query);
			purId=pur.getPurchaseid();
			pst.setInt(1,purId );
			System.out.println( pur.getCname()+pur.getMailid()+pur.getPhoneno()+pur.getMobileid()+pur.getDate());
			pst.setString(2, pur.getCname());
			pst.setString(3, pur.getMailid());
			pst.setString(4, pur.getPhoneno());
			//pst.setDate(5, pur.getDate());
			mobId= pur.getMobileid();
			pst.setInt(5, mobId);
			System.out.println("heo");
			
			String mobQtyQuery="Select quantity from mobiles where mobileid=?";
			PreparedStatement pst2= conn.prepareStatement(mobQtyQuery);
			pst2.setInt(1, mobId);
			ResultSet rs= pst2.executeQuery();
			
			while(rs.next()){
				qty = Integer.parseInt(rs.getString(1));
				if(qty>0){
					rec= pst.executeUpdate();
					System.out.println(rec);
					return true;
				}else{
					System.out.println("Stock Empty!");
				}
			}
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new MobileException("Purchase details could not be updated");
		}finally{
			try {
				conn.close();
				pst.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			
			}	
		}
		return false;
	}

	@Override
	public List<Purchase> showPurchaseDetails() throws MobileException {
		// TODO Auto-generated method stub
		String query= "SELECT * FROM purchasedetails";
		conn= JdbcUtil.getConnection();
		
		try {
			pst= conn.prepareStatement(query);
			ResultSet result= pst.executeQuery();
			
			while(result.next()){
				int purchase_id= result.getInt("purchaseid");
				String cust_name= result.getString("cname");
				String mail_id= result.getNString("mailid");
				String phone_no= result.getString("phoneno");
				Date purchase_date= result.getDate("purchasedate");
				int mobile_id= result.getInt("mobileid");
				
				Purchase purchase1= new Purchase();
				
				purchase1.setCname(cust_name);
				purchase1.setMailid(mail_id);
				purchase1.setPhoneno(phone_no);
				purchase1.setDate(purchase_date);
				purchase1.setMobileid(mobile_id);
				
				puchaseList.add(purchase1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			throw new MobileException("No detail exists!");
		}	
		return puchaseList;
	}
}
