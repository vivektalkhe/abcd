package com.cg.ma.dao;

import java.util.List;

import com.cg.ma.Exception.MobileException;
import com.cg.ma.dto.Mobile;
import com.cg.ma.dto.Purchase;

public interface ImobileDao {

	 //boolean insertMobile( Mobile mobile ) throws MobileException;
	 List<Mobile> showAll() throws MobileException;
	 boolean deleteMobile(int mobileId) throws MobileException;
	 List<Mobile> searchByRange(int start, int end) throws MobileException;
	 boolean updateQty(int mobileid, int qty) throws MobileException;
	 
	
	

	 
	 
}
