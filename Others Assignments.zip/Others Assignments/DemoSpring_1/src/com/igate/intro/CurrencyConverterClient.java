package com.igate.intro;
import org.springframework.beans.factory.*;
import org.springframework.beans.factory.xml.*;
import org.springframework.core.io.*;

public class CurrencyConverterClient {

	public static void main(String args[]) throws Exception {
		Resource res = new ClassPathResource("currencyconverter.xml");
		System.out.println("1");
		BeanFactory factory = new XmlBeanFactory(res);//container of spring
		System.out.println("2");
		CurrencyConverter curr = (CurrencyConverter) factory.getBean("currencyConverter");//alias given in xml and will get the setter methods
		System.out.println("3");
		double rupees = curr.dollarsToRupees(50.0);
		System.out.println("50 $ is "+rupees+" Rs.");
	}
}
