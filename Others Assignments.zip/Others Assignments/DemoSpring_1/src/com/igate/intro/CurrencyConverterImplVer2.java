package com.igate.intro;

public class CurrencyConverterImplVer2 extends CurrencyConverterImpl {
	@Override
	public double dollarsToRupees(double dollars) {
		System.out.println("dollarsToRupees() from version 2");		
		return dollars * super.getExchangeRate()* 0.02f;
	}
}
