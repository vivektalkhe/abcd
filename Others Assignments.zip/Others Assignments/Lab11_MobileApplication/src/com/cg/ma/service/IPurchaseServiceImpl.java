package com.cg.ma.service;

import java.util.List;
import java.util.regex.Pattern;


import com.cg.ma.Exception.MobileException;

import com.cg.ma.dao.IPurchaseDao;
import com.cg.ma.dao.IPurchaseDaoImpl;
import com.cg.ma.dto.PurchaseDetails;

public class IPurchaseServiceImpl implements IPurchaseService{
	IPurchaseDao purchasedao=new IPurchaseDaoImpl();
	@Override
	public int addPurchaseDetail(PurchaseDetails purchase) throws MobileException
	{
		return purchasedao.addPurchaseDetails(purchase);
		
		
	}
	
	
	public List<PurchaseDetails> showPurchaseDetail() throws MobileException
	{
		return purchasedao.showPurchaseDetails();
		
	}
	public static void validateName(String patt,String name) throws MobileException{
	boolean value=Pattern.matches(patt,name);
	if(!value){
		throw new MobileException("Name should be of minimum 4 and maximum 10 and First letter must be capital");
	}
		
	}
	public static void validatePhoneno(String patt,String name) throws MobileException{
		boolean value=Pattern.matches(patt,name);
		if(!value){
			throw new MobileException("PhoneNo must be of 10 digits and should start with 7 or 8 or 9");
		}
			
		}
	public static void validateMailid(String patt,String name) throws MobileException{
		boolean value=Pattern.matches(patt,name);
		if(!value){
			throw new MobileException("Please Enter Valid Email id");
		}
			
		}
	public static void validateMobilId(String patt,String name) throws MobileException{
		boolean value=Pattern.matches(patt,name);
		if(!value){
			throw new MobileException("MobileId should be of 4 digits  and should start with 1");
		}
			
		}


	@Override
	public int checkServiceMobileid(int mid) throws MobileException {
		// TODO Auto-generated method stub
		return purchasedao.checkMobileid(mid);
	}
}
