
package com.cg.ma.ui;


import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import com.cg.ma.Exception.MobileException;
import com.cg.ma.dto.MobileDetails;
import com.cg.ma.dto.PurchaseDetails;
import com.cg.ma.service.IMobileService;
import com.cg.ma.service.IMobileServiceImpl;
import com.cg.ma.service.IPurchaseService;
import com.cg.ma.service.IPurchaseServiceImpl;

public class MobileApplication {
	private static	final Logger mylogger=Logger.getLogger(MobileApplication.class);
public static void main(String args[]) throws MobileException
{
	
	mylogger.info("Application Started");
	IMobileService mobileService=new IMobileServiceImpl();
	IPurchaseService purchaseService=new IPurchaseServiceImpl();
	PurchaseDetails purchase=new PurchaseDetails();
	Scanner sc=new Scanner(System.in);
	
	int choice=0;
	do{
		printDetail();
	
	System.out.println("Please Enter your Choice:");
	choice=sc.nextInt();
	switch(choice){
	case 1:
		mylogger.info("Inserting Data in purchasedetails");
		String pname="^[A-Z][a-z]{2,19}$";
		System.out.println(" Enter Customer Name");
		
		String Cname=sc.next();
		try { 
		IPurchaseServiceImpl.validateName(pname,Cname);
		purchase.setCname(Cname);
		} catch (MobileException m1) {
			
			System.out.println(m1.getMessage());
			mylogger.error("Customer name Not Inserted");
			break;
			//throw new MobileException("Data Not Inserted Please Enter Proper Name");
		}
		String pmail="^(.+)@(.+)$";
		System.out.println(" Enter Email Id: ");
		String emailid=sc.next();
		try {
			IPurchaseServiceImpl.validateMailid(pmail,emailid);
			purchase.setMailid(emailid);
		} catch (MobileException m1) {
			mylogger.error("Email not inserted");
			System.out.println(m1.getMessage());
			break;
		}
		
		String pnum="^[7|8|9]{1}[0-9]{9}$";
		System.out.println(" Enter Phoneno:");
		String phoneno=sc.next();
		try {
			IPurchaseServiceImpl.validatePhoneno(pnum,phoneno);
			purchase.setPhoneno(phoneno);
		} catch (MobileException m1) {
			
			System.out.println(m1.getMessage());
			mylogger.error("PhoneNo not inserted");
			break;
		}
		
		String pmobilid="^[1]{1}[0-9]{3}$";
		System.out.println(" Enter mobileID:");
		String mobileid=sc.next();
		try {
			IPurchaseServiceImpl.validateMobilId(pmobilid,mobileid);
			
			int mid=Integer.parseInt(mobileid);
			
			int flag=purchaseService.checkServiceMobileid(mid);
			if(flag==1)
				purchase.setMobileid(mid);
			else
			{
				
				throw new MobileException("Please Enter Proper Mobile ID");
			}
		
		} catch (MobileException m1) {
			mylogger.error("Mobile Id not Inserted");
			System.out.println(m1.getMessage());
			
			break;
		}
		
		purchase.setPurchasedate(purchase.getPurchasedate());
		
		
		try {
			int pId=purchaseService.addPurchaseDetail(purchase);
			if(pId>0){
System.out.println("Welcome User your Purchase Id is "+pId);
mylogger.info("Purchase Id:" +pId);
			}else{
System.out.println("Data Not Inserted");
			}
		} catch (MobileException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			//System.out.println(e.getMessage());
			System.out.println("Data Not Inserted..");
		}
		mylogger.info("Customer Information Added Successfully");
		break;
		
	case 2:
		mylogger.info("Displaying Data of purchasedetails");
		List<PurchaseDetails> lpurchase=null;
		try {
			lpurchase = purchaseService.showPurchaseDetail();
		} catch (MobileException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			throw new MobileException("Data Not Displayed");
		}
		for (PurchaseDetails pdetails : lpurchase) {
			System.out.println(" Purchase Id : "+pdetails.getPurchaseid());
			System.out.println("Customer Name :"+pdetails.getCname());
			System.out.println(" Email ID : "+pdetails.getMailid());
			System.out.println(" Phone No : " +pdetails.getPhoneno());
			System.out.println("Purchase Date: "+pdetails.getPurchasedate());
			System.out.println("Mobile ID: " +pdetails.getMobileid());
		}
		mylogger.info("Purchase Information");
		break;
		
	case 3:
		mylogger.info("Displaying data of all Mobiles");
		List<MobileDetails> lmobile=null;
		try {
			lmobile = mobileService.ShowAll();
		} catch (MobileException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			throw new MobileException("Data Not Displayed");
		}
		for (MobileDetails mdetails : lmobile) {
			System.out.println(" Mobile Id : "+ mdetails.getMobileid());
			System.out.println("Mobile Name :"+ mdetails.getMobilename());
			System.out.println(" Price: "+ mdetails.getPrice());
			System.out.println(" Quantity : " + mdetails.getQuantity());
	}
		mylogger.info("Mobiles Information");
		break;
		
	case 4:
		mylogger.info("Searching for mobile");
		List<MobileDetails> mobilelist=new ArrayList<MobileDetails>();
System.out.println(" Enter Price Range:");
		int minprice=sc.nextInt();
		int maxprice=sc.nextInt();
		
		try {
			mobilelist= mobileService.SearchPrice(minprice, maxprice);
			
		} catch (MobileException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			throw new MobileException("Not a Proper Range.Please Enter Proper Price Range");
		}
		for(MobileDetails m:mobilelist)
		{
			System.out.println(m);
		}
		mylogger.info("Mobile Searched");
		break;
		
	case 5:
		mylogger.info("Deleting mobile information");
		System.out.println("Enter the mobileid:");
		int rmobileid=sc.nextInt();
		try {
			mobileService.DeleteMobileDetails(rmobileid);
			System.out.println("Record Removed successfully.");
		} catch (MobileException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			throw new MobileException("Mobile ID not deleted");
		}
		mylogger.info("Mobile Information Deleted.");
		break;
	case 6:
		mylogger.info("Updating mobiles information");
		System.out.println("Enter Mobile ID:");
		int qmobileid=sc.nextInt();
		System.out.println("Enter No. of mobiles sold:");
		int soldmobile=sc.nextInt();
		try {
			
	boolean flag=mobileService.UpdateQtyService(qmobileid,soldmobile);
if(flag)
		System.out.println("Successfully updated");
		} catch (MobileException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			throw new MobileException("Failed to Update");
		}
		mylogger.info("Mobiles Information Updated");
		break;
	case 7:
		mylogger.info("Exit From Application");
		System.out.println("Exit From application");
		
		System.exit(0);
		
		break;
		
		default:
			System.out.println("Please Enter Right Choice");
			break;
		
	}//sc.close();
	}while(choice!=7);
	sc.close();
	
	
	
}
public static void printDetail(){
	System.out.println("**********");
	System.out.println("1. Add Purchase Details ");
	System.out.println("2. Show Purchase Details");
	System.out.println("3. Show All Mobiles");
	System.out.println("4. Search For Mobile");
	System.out.println("5. Remove Mobile ");
	System.out.println("6. Update Mobile Quantity");
	System.out.println("7. Exit");
	System.out.println("***********");
}

}
