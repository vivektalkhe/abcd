package com.cg.ma.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.ma.Exception.MobileException;
import com.cg.ma.JdbcUtil.JdbcUtil;
import com.cg.ma.dto.MobileDetails;

public class IMobileDaoImpl implements IMobileDao {
	Connection conn;
	PreparedStatement ps = null;

	@Override
	public List<MobileDetails> ShowMobileData() throws MobileException {

		List<MobileDetails> mobilelist = new ArrayList<MobileDetails>();
		conn = JdbcUtil.getConnection();
		String query = "SELECT * from mobiles";
		try {
			ps = conn.prepareStatement(query);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				MobileDetails mdetails = new MobileDetails();
				mdetails.setMobileid(rs.getInt("mobileid"));
				mdetails.setMobilename(rs.getString("name"));
				mdetails.setPrice(rs.getDouble("price"));
				mdetails.setQuantity(rs.getDouble("quantity"));
				mobilelist.add(mdetails);
			}

		} catch (SQLException e) {
			System.out.println(e);
			
			throw new MobileException("Data Not Found");
		} finally {

			try {
				ps.close();
				conn.close();
			} catch (SQLException e) {
				System.out.println(e);
				
			}

		}

		return mobilelist;
	}

	@Override
	public boolean RemoveMobileDetails(int mobileid) throws MobileException {
		conn = JdbcUtil.getConnection();
		int rec = 0;
		String query = "DELETE FROM mobiles where mobileid=?";
		try {
			ps = conn.prepareStatement(query);
			ps.setInt(1, mobileid);
			rec = ps.executeUpdate();
			if (rec > 0)
				return true;
			

		} catch (SQLException e) {
			System.out.println(e);
			
		} finally {
			try {
				ps.close();
				conn.close();
			} catch (SQLException e) {
				System.out.println(e);
				throw new MobileException("Data Not Removed");
			}

		}

		return false;
	}

	@Override
	public List<MobileDetails> SearchByPrice(double minprice, double maxprice)
			throws MobileException {
		conn = JdbcUtil.getConnection();
		String query = "SELECT * FROM mobiles where price>=? AND price<=?";
		List<MobileDetails> mobilelist = new ArrayList<MobileDetails>();
		try {
			ps = conn.prepareStatement(query);
			ps.setDouble(1, minprice);
			ps.setDouble(2, maxprice);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				MobileDetails mdetails = new MobileDetails();
				mdetails.setMobileid(rs.getInt("mobileid"));
				mdetails.setMobilename(rs.getString("name"));
				mdetails.setPrice(rs.getDouble("price"));
				mdetails.setQuantity(rs.getDouble("quantity"));
				mobilelist.add(mdetails);
			}
if(mobilelist.isEmpty())
{
	System.out.println("Mobiles for this Range is out of Stock");
}
		} catch (SQLException e) {
			System.out.println(e);
			throw new MobileException("Data Not Found");
		} finally {
			try {
				ps.close();
				conn.close();
			} catch (SQLException e) {
				System.out.println(e);
			}

		}

		return mobilelist;
	}


	@Override
	public boolean UpdateQty(int mobileid, double qty) throws MobileException {
		conn = JdbcUtil.getConnection();
		String query1="select quantity from mobiles where mobileid=?";
		int rec=0;
		int quantity1=0;
		try {
			ps=conn.prepareStatement(query1);
			ps.setInt(1,mobileid);
			ResultSet rs=ps.executeQuery();
			
			while(rs.next())
			{
				quantity1=rs.getInt("quantity");
				
			}
		}
		catch (SQLException e) {
			System.out.println(e);
			throw new MobileException("Not getting Quantity");
		}
			
			if(quantity1>qty)
			{
				String query = "UPDATE mobiles SET quantity =quantity-? where mobileid=? ";
				try {
					ps = conn.prepareStatement(query);
					ps.setDouble(1, qty);
					ps.setInt(2, mobileid);
				rec = ps.executeUpdate();
				
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}finally {
					try {
						ps.close();
						conn.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						//e.printStackTrace();
					}

				}
				
			}
			else
			{
				System.out.println("Quantity is out of range");
			}
			if(rec>0)
			{
				return true;
			}
			
		return false;
	}

}
