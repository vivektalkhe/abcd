package com.cg.ma.dao;

import java.util.List;

import com.cg.ma.Exception.MobileException;
import com.cg.ma.dto.MobileDetails;

public interface IMobileDao {
List<MobileDetails> ShowMobileData() throws MobileException ; 
boolean RemoveMobileDetails(int mobileid) throws MobileException;
List<MobileDetails> SearchByPrice(double minprice,double maxprice) throws MobileException; 
boolean UpdateQty(int mobileid,double qty) throws MobileException;
}
