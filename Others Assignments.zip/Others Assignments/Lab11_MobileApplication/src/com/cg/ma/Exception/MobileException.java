package com.cg.ma.Exception;

@SuppressWarnings("serial")
public class MobileException extends Exception{
public MobileException(String msg)
{
	super(msg);
}
}
