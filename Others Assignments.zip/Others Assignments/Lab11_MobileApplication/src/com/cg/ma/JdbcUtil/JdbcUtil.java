package com.cg.ma.JdbcUtil;


import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import org.apache.log4j.Logger;


import com.cg.ma.Exception.MobileException;




public class JdbcUtil {
private static	final Logger mylogger=Logger.getLogger(JdbcUtil.class);
		
		public static Connection getConnection() throws MobileException{
			
			 Connection conn=null;
			Properties pros=new Properties();
			try {
		InputStream fileRead=new FileInputStream("D:\\Lab11_MobileApplication\\oracle.properties");
		pros.load(fileRead);
		String driver=pros.getProperty("oracle.driver");
		String url=pros.getProperty("oracle.url");
		String userName=pros.getProperty("oracle.uname");
		String password=pros.getProperty("oracle.upass");
		
		Class.forName(driver);
	conn=DriverManager.getConnection(url, userName, password);
	
	mylogger.info("Coneection Esablished.....");
	
			} catch (IOException | ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
				mylogger.error("Coneection not Esablished.....");
				throw new MobileException("Connection problem");
				
			}
			return conn;
		
	}

}
