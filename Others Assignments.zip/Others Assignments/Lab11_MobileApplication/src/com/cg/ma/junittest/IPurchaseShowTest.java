package com.cg.ma.junittest;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.ma.Exception.MobileException;

import com.cg.ma.dao.IPurchaseDaoImpl;


public class IPurchaseShowTest {
	IPurchaseDaoImpl purchasedao=null;

	@Before
	public void setup()
	{
		purchasedao=new IPurchaseDaoImpl();
	}
	@Test
	public void testShowMobileData() {
		
		try {
			assertNotNull(purchasedao.showPurchaseDetails());
		} catch (MobileException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}



	@After
	public void tearDown()
	{
		purchasedao=null;
	}
}
