package com.cg.ma.junittest;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.ma.dao.IPurchaseDaoImpl;

public class IPurchaseMobilidTest {
	IPurchaseDaoImpl purchasedao=null;

	@Before
	public void setup()
	{
		purchasedao=new IPurchaseDaoImpl();
	}
	@Test
	public void testCheckMobileid() {
		assertEquals(1,purchasedao.checkMobileid(1003));
	}
	@After
	public void tearDown()
	{
		purchasedao=null;
	}
}
