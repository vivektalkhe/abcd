package com.cg.ma.junittest;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.ma.Exception.MobileException;
import com.cg.ma.dao.IMobileDaoImpl;

public class IMobileSearchTest {
	IMobileDaoImpl mobiledao=null;
	@Before
	public void setup()
	{
		mobiledao=new IMobileDaoImpl();
	}
	@Test
	public void testSearchByPrice() throws MobileException {
		assertNotNull(mobiledao.SearchByPrice(10000, 40000));
	}
	@After
	public void tearDown()
	{
		mobiledao=null;
	}
}
