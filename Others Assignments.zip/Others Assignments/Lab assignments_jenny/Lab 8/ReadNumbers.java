package com.lab8;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class ReadNumbers {

	public static void main(String[] args) {
		try(FileReader fr = new FileReader("d:\\numbers.txt");){
			Scanner sc = new Scanner(fr);
			sc.useDelimiter(",");
			while(sc.hasNextInt()){
				if(sc.hasNextInt()){
					int number=sc.nextInt();
					if(number % 2 == 0){
						System.out.println(number);
					}
				}
			}
			sc.close();
			 
			
			
			
			
			
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		} catch (IOException e) {
			
			e.printStackTrace();
		}

	}

}
