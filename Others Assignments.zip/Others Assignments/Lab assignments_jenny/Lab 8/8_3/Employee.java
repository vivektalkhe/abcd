package com.cg.lab8_3;

import java.io.Serializable;

import com.cg.lab8_3.EmployeeException;

public class Employee implements Serializable {
	private int id;
	private String name;
	private double salary;
	private String designation;
	private String insuranceScheme;
	
	

	public Employee() {
		super();
	}

	
	public Employee(int id, String name, double salary, String designation)throws EmployeeException {
		super();
		this.id = id;
		this.name = name;
		if(salary<3000){
			throw new EmployeeException("Salary should be greater than 3000");
		}
		else{
			this.salary = salary;
		}
		
		this.designation = designation;
		
		
	}


	public int getId() {
		return id;
	}



	public void setId(int id) {
		this.id = id;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public double getSalary() {
		return salary;
	}



	public void setSalary(double salary)throws EmployeeException {
		if(salary<3000){
			throw new EmployeeException("Salary should be greater than 3000");
		}else{
		this.salary = salary;
		}
	}



	public String getDesignation() {
		return designation;
	}



	public void setDesignation(String designation) {
		this.designation = designation;
	}



	public String getInsuranceScheme() {
		return insuranceScheme;
	}

	



	public void setInsuranceScheme(String insuranceScheme) {
		this.insuranceScheme = insuranceScheme;
	}


	public void showDetails(){
		System.out.println("Employee ID: "+id);
		System.out.println("Employee Name: "+name);
		System.out.println("Employee Salary: "+salary);
		System.out.println("Employee Designation: "+designation);
		System.out.println("Employee Insurance Scheme: "+insuranceScheme);
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", salary=" + salary
				+ ", designation=" + designation + ", insuranceScheme="
				+ insuranceScheme + "]";
	}



	
	
	
	
}
