package com.cg.lab8_3;

import com.cg.lab8_3.EmployeeException;

public interface EmployeeService {
	public void inputEmployee() throws EmployeeException;
	public void findInsuranceScheme();
	public void copyFileWrite() throws EmployeeException;
	public void copyFileRead();
	public void displayDetail();
}
