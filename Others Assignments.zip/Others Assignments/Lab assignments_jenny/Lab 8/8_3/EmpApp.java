package com.cg.lab8_3;

import com.cg.lab8_3.EmployeeException;
import com.cg.lab8_3.EmployeeService;
import com.cg.lab8_3.EmployeeServiceImpl;

public class EmpApp {

	public static void main(String[] args) throws com.cg.eis.exception.EmployeeException, EmployeeException {
		EmployeeService service=new EmployeeServiceImpl();
		try {
			service.inputEmployee();
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		service.findInsuranceScheme();
		service.copyFileWrite();
		service.copyFileRead();
		service.displayDetail();

	}

}
