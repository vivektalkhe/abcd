package com.cg.lab8_3;

public class EmployeeException extends Exception{

	public EmployeeException(String msg){
		super(msg);
	}
}
