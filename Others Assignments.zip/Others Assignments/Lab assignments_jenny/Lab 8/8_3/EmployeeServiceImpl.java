package com.cg.lab8_3;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Scanner;

import com.cg.lab8_3.Employee;
import com.cg.lab8_3.EmployeeException;

public class EmployeeServiceImpl implements EmployeeService {

	Employee e;
	int id;
	String name;
	double salary;
	String designation;
	String insuranceScheme;
	
	@Override
	public void inputEmployee() throws EmployeeException {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter id");
		id=sc.nextInt();
		System.out.println("Enter name");
		name=sc.next();
		System.out.println("Enter salary");
		salary=sc.nextDouble();
		System.out.println("Enter designation");
		designation=sc.next();
		e=new Employee(id, name, salary, designation);
		sc.close();
		
	}

	@Override
	public void findInsuranceScheme() {
		
		double salary=e.getSalary();
		String designation=e.getDesignation();
		if((salary>5000 && salary<20000) && designation.equals("System Associate")){
			insuranceScheme="C";
		}
		else if((salary>=20000 && salary<40000) && designation.equals("Programmer")){
			insuranceScheme="B";
		}
		else if(salary>=40000  && designation.equals("Manager")){
			insuranceScheme="A";
		}
		else if(salary<5000 && designation.equals("Clerk")){
			insuranceScheme="No Scheme";
		}
		e.setInsuranceScheme(insuranceScheme);
	}
	
	public void copyFileWrite() throws EmployeeException {
		
		Employee emp[]={new Employee(id,name,salary,designation)};
		try (FileOutputStream out = new FileOutputStream("d:\\copyFile.txt");
			ObjectOutputStream sout = new ObjectOutputStream(out);){
			
			
			
			for(int i = 0; i <emp.length ; i++){
				sout.writeObject(emp[i]);
			}
			
			
		} catch (FileNotFoundException e) {
		
			e.printStackTrace();
		} catch (IOException e) {
			
			e.printStackTrace();
		} 
	}
	
	public void copyFileRead(){
		try(FileInputStream in = new FileInputStream("d:\\copyFile.txt");
				ObjectInputStream sin = new ObjectInputStream(in);){
			Employee eis = (Employee) sin.readObject();
			
			
			
				
			e.showDetails();
			sin.close();
			
		} catch (IOException e) {
			
			e.printStackTrace();
		} catch (ClassNotFoundException e1) {
			
			e1.printStackTrace();
		}
	}

	@Override
	public void displayDetail() {
		//System.out.println(e);
		
	}

}
