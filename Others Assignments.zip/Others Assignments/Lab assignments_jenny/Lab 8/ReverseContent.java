package com.lab8;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class ReverseContent {
	public static void main(String[] args) {
			
		try(FileReader fr = new FileReader("d:\\wordcount.txt");
				FileWriter fw = new FileWriter("d:\\copywordcount.txt")){
			
			File f = new File("d:\\wordcount.txt");
			int size=(int) f.length();
			char[] arr = new char[size];
			int ch;
			int i=0;
					
			ch=fr.read();
			while(ch!=-1){
				arr[i]=(char)ch;
				
				i++;
				ch=fr.read();
			}
			
			
			
			for(int j=size-1;j>0;j--){
				fw.write(arr[j]);
			}
			
			
			
			
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	}
	
}
