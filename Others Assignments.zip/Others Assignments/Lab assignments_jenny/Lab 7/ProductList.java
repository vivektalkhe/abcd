package com.lab7;

import java.util.ArrayList;
import java.util.Collections;

public class ProductList {

	public static void main(String[] args) {
		ArrayList<String> pList = new ArrayList<>();
		
		pList.add("banana");
		pList.add("Apple");
		pList.add("Grapes");
		pList.add("Guava");
		pList.add("Chickoo");
		pList.add("Pineapple");
		
		System.out.println("List before sorting:");
		System.out.println(pList);
		
		Collections.sort(pList);
		
		System.out.println(" ");
		System.out.println("List after sorting:");
		System.out.println(pList);

		System.out.println(" ");
		System.out.println("List after sorting using ForEach loop:");
		for(String list:pList){
			System.out.println(list);
		}
	}

}
