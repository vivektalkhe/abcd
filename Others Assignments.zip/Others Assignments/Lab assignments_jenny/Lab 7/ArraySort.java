package com.lab7;

import java.util.Arrays;

public class ArraySort {
	
	public static void main(String[] args){
		String products[] = {"banana","Apple","Glass"};
		for(String pd:products){
			System.out.println(pd);
		}
		System.out.println(" ");
		System.out.println("After sort");
		Arrays.sort(products);
		for(String pd:products){
			System.out.println(pd);
		}
	}
	
	
}
