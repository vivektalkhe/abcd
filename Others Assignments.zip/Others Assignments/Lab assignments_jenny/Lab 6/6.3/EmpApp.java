package com.cg.eis.pl;

import com.cg.eis.exception.EmployeeException;
import com.cg.eis.service.EmployeeService;
import com.cg.eis.service.EmployeeServiceImpl;

public class EmpApp {

	public static void main(String[] args) throws EmployeeException {
		EmployeeService service=new EmployeeServiceImpl();
		service.inputEmployee();
		service.findInsuranceScheme();
		service.displayDetail();

	}

}
