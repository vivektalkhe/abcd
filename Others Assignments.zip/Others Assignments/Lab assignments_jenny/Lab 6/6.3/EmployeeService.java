package com.cg.eis.service;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.EmployeeException;

public interface EmployeeService {
	public void inputEmployee() throws EmployeeException;
	public void findInsuranceScheme();
	public void displayDetail();
}
