
public class Person1 {



	String firstname;
	String lastname;
	Gender gender;
	String phn;
	

	public Person1() {
		super();
	}

	
	public Person1(String firstname, String lastname, Gender gender)throws NameException {
		super();
		if(firstname.length() != 0)
		{
		this.firstname = firstname;
		}else{
			throw new NameException("Firstname must be entered");
		}
		if(lastname.length() != 0)
		{
			this.lastname = lastname;
		}else{
			throw new NameException("Lastname must be entered");
		}
		
		this.gender = gender;
	}


	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname)throws NameException {
		if(firstname.length() != 0)
		{
		this.firstname = firstname;
		}else{
			throw new NameException("Firstname must be entered");
		}
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname)throws NameException {
		if(lastname.length() != 0)
		{
			this.lastname = lastname;
		}else{
			throw new NameException("Lastname must be entered");
		}
	}

	
	public Gender getGender() {
		return gender;
	}

	public void setGender(Gender gender) {
		this.gender = gender;
	}

	public String getPhn() {
		return phn;
	}

	public void setPhn(String phn) {
		this.phn = phn;
	}
	
	void display(){
		System.out.println("Firstname:"+firstname);
		System.out.println("Lastname:"+lastname);
		System.out.println("Gender:"+gender);
		System.out.println("Phone number:"+phn);
		
	}
		

}










