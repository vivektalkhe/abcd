
public class NameException extends Exception {
 public NameException(String msg){
	 super(msg);
 }
}
