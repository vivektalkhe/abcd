package com.lab4_2;

public class AgeException extends Exception{

	public AgeException(String msg){
		super(msg);
	}
}
