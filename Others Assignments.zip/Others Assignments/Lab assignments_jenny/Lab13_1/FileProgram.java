package lab13_1;

public class FileProgram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
CopyDataThread cp=new CopyDataThread();
cp.start();
	}

}
