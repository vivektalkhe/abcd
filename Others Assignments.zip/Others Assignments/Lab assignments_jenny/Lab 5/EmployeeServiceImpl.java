package com.cg.eis.service;

import java.util.Scanner;

import com.cg.eis.bean.Employee;

public class EmployeeServiceImpl implements EmployeeService {

	Employee e;
	@Override
	public void inputEmployee() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter id");
		int id=sc.nextInt();
		System.out.println("Enter name");
		String name=sc.next();
		System.out.println("Enter salary");
		double salary=sc.nextDouble();
		System.out.println("Enter designation");
		String designation=sc.next();
		e=new Employee(id, name, salary, designation);
		sc.close();
		
	}

	@Override
	public void findInsuranceScheme() {
		String insuranceScheme=null;
		double salary=e.getSalary();
		String designation=e.getDesignation();
		if((salary>5000 && salary<20000) && designation.equals("System Associate")){
			insuranceScheme="C";
		}
		else if((salary>=20000 && salary<40000) && designation.equals("Programmer")){
			insuranceScheme="B";
		}
		else if(salary>=40000  && designation.equals("Manager")){
			insuranceScheme="A";
		}
		else if(salary<5000 && designation.equals("Clerk")){
			insuranceScheme="No Scheme";
		}
		e.setInsuranceScheme(insuranceScheme);
	}

	@Override
	public void displayDetail() {
		System.out.println(e);
		
	}

}
