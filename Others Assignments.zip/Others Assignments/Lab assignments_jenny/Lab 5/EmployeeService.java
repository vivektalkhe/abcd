package com.cg.eis.service;

import com.cg.eis.bean.Employee;

public interface EmployeeService {
	public void inputEmployee();
	public void findInsuranceScheme();
	public void displayDetail();
}
