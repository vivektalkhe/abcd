package com.lab4_2;

public class Accounts {

	private long accNum;
	private double balance;
	private Person accHolder;
	static int count;
	public Accounts() {
		super();
		count++;
		accNum=count;
	}
	public Accounts(double balance) {
		super();
		count++;
		this.accNum = count;
		this.balance = balance;
	}
	public long getAccNum() {
		return accNum;
	}
	public double getBalance() {
		return balance;
	}
	public Person getAccHolder() {
		return accHolder;
	}
	
	
	public void setAccHolder(Person accHolder) {
		this.accHolder = accHolder;
	}
	public void deposit(double amt){
		balance+=amt;
	}
	
	public void withdraw(double amt){
		balance-=amt;
		
	}
	@Override
	public String toString() {
		return "AccountsDetails accNum=" + accNum + ", balance=" + balance
				+ ", accHolder=" + accHolder ;
	}
	
	
}
