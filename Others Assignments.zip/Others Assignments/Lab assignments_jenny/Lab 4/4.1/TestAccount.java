package com.lab4;

public class TestAccount {

	public static void main(String[] args) {
		int i=0;
		Person smith = new Person("Smith",23);
		Person kathy = new Person("Kathy",21);
		
		Accounts smithAccount = new Accounts(++i,2000);
		smithAccount.setAccHolder(smith);
		System.out.println(smithAccount);
		
		Accounts kathyAccount = new Accounts(++i,3000);
		kathyAccount.setAccHolder(kathy);
		System.out.println(kathyAccount);
		
		smithAccount.deposit(2000);
		kathyAccount.withdraw(2000);
		System.out.println("Updated Balance of Smith "+smithAccount.getBalance());
		System.out.println("Updated Balance of Kathy "+kathyAccount.getBalance());
		

	}

}
