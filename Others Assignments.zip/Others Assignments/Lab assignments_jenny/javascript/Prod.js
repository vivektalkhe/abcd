function order()
{
	
var B1=document.getElementById("A1").value;
var B2=document.getElementById("A2").value;
var B3=document.getElementById("A3").value;
var B4=document.getElementById("A4").value;

var i;
var total;
}
function display()
{
alert('display')
}