import java.util.Scanner;

public class PersonMain {

	public static void main(String[] args) {
		Gender gender=null;
		Person person = new Person();
		
		System.out.println("Person Details:");
		System.out.println("_______________");
		System.out.println("               ");
		
		Scanner sc1 = new Scanner(System.in);
		System.out.println("Enter firstname");
		String firstname = sc1.nextLine();
		person.setFirstname(firstname);
		
		Scanner sc2 = new Scanner(System.in);
		System.out.println("Enter last name");
		String lastname = sc2.nextLine();
		person.setLastname(lastname);
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter phone number");
		String phn = sc.nextLine();
		person.setPhn(phn);
		
		System.out.println("Enter gender");
		String p_gender = sc.nextLine();
		gender=Gender.valueOf(p_gender);
		person.setGender(gender);
		
		sc1.close();
		sc2.close();
		sc.close();
		person.display();

	}

}