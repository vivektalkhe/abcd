
public enum Gender {
	F,M,m,f;

}
