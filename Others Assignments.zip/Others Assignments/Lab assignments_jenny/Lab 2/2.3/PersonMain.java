import java.util.Scanner;

public class PersonMain {

	public static void main(String[] args) {
		
		Person person = new Person();
		
		System.out.println("Person Details:");
		System.out.println("_______________");
		System.out.println("               ");
		
		Scanner sc1 = new Scanner(System.in);
		System.out.println("Enter firstname");
		String firstname = sc1.nextLine();
		person.setFirstname(firstname);
		
		Scanner sc2 = new Scanner(System.in);
		System.out.println("Enter last name");
		String lastname = sc2.nextLine();
		person.setLastname(lastname);
		
				
		System.out.println("Enter gender");
		char gender = sc.nextLine();
		person.setGender(gender);
		
		sc1.close();
		sc2.close();
		sc.close();
		person.display();

	}

}