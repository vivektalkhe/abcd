package com.cgmobilesalesshop.dto;

public class Mobile {

	private int mobileId;
	private String mobileName;
	private double price;
	private int quantity;

	public Mobile() {
		super();
	}

	public Mobile(int mobileId, String mobileName, double price, int quantity) {
		super();
		this.mobileId = mobileId;
		this.mobileName = mobileName;
		this.price = price;
		this.quantity = quantity;
	}

	public int getMobileId() {
		return mobileId;
	}

	public String getMobileName() {
		return mobileName;
	}

	public double getPrice() {
		return price;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setMobileId(int mobileId) {
		this.mobileId = mobileId;
	}

	public void setMobileName(String mobileName) {
		this.mobileName = mobileName;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public String toString() {
		return "Mobile mobileId=" + mobileId + ", mobileName=" + mobileName
				+ ", price=" + price + ", quantity=" + quantity;
	}

}
