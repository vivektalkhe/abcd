package com.cgmobilesalesshop.dto;

import java.util.Date;

public class PurchaseDetails {

	private int purchaseid;
	private String customerName;
	private String mailId;
	private String phoneNo;
	private Date purchaseDate;
	private int mobileId;
	public PurchaseDetails() {
		super();
	}
	public PurchaseDetails(int purchaseid, String customerName, String mailId,
			String phoneNo, Date purchaseDate, int mobileId) {
		super();
		this.purchaseid = purchaseid;
		this.customerName = customerName;
		this.mailId = mailId;
		this.phoneNo = phoneNo;
		this.purchaseDate = purchaseDate;
		this.mobileId = mobileId;
	}
	public int getPurchaseid() {
		return purchaseid;
	}
	public void setPurchaseid(int purchaseid) {
		this.purchaseid = purchaseid;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getMailId() {
		return mailId;
	}
	public void setMailId(String mailId) {
		this.mailId = mailId;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public Date getPurchaseDate() {
		return purchaseDate;
	}
	public void setPurchaseDate(Date purchaseDate) {
		this.purchaseDate = purchaseDate;
	}
	public int getMobileId() {
		return mobileId;
	}
	public void setMobileId(int mobileId) {
		this.mobileId = mobileId;
	}
	@Override
	public String toString() {
		return "PurchaseDetails purchaseid=" + purchaseid + ", customerName="
				+ customerName + ", mailId=" + mailId + ", phoneNo=" + phoneNo
				+ ", purchaseDate=" + purchaseDate + ", mobileId=" + mobileId;
	}
	
}
