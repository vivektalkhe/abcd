package com.cg.mobilesalesshop.exception;

public class MobileException extends Exception {
	public MobileException(String msg){
		super(msg);
	}

}
