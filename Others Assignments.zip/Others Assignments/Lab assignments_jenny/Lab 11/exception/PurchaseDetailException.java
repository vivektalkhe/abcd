package com.cg.mobilesalesshop.exception;

public class PurchaseDetailException extends Exception {

	public PurchaseDetailException(String msg){
		super(msg);
	}
}
