package com.cg.mobilesalesshop.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.mobilesalesshop.exception.MobileException;
import com.cg.mobilesalesshop.exception.PurchaseDetailException;
import com.cg.mobilesalesshop.util.JdbcUtil;
import com.cgmobilesalesshop.dto.Mobile;
import com.cgmobilesalesshop.dto.PurchaseDetails;

public class MobileDaoImpl implements IMobileDao {
	private static final Logger mylogger = Logger.getLogger(JdbcUtil.class);
	Connection connect;
	PreparedStatement pst;
	PreparedStatement pst2;

	public List<Mobile> showAllDetails() throws MobileException {
		connect = JdbcUtil.getConnection();
		JdbcUtil j = new JdbcUtil();
		PropertyConfigurator.configure("log4j.properties");
		mylogger.info("showAllDetail Method Started");
		String query = "SELECT * FROM mobiles";
		List<Mobile> mList = new ArrayList<Mobile>();
		try {
			pst = connect.prepareStatement(query);
			ResultSet rst = pst.executeQuery();
			while (rst.next()) {
				int m_id = rst.getInt("MOBILEID");
				String m_name = rst.getString("NAME");
				double m_price = rst.getInt("PRICE");
				int m_qty = rst.getInt("QUANTITY");
				Mobile m = new Mobile();
				m.setMobileId(m_id);
				m.setMobileName(m_name);
				m.setPrice(m_price);
				m.setQuantity(m_qty);
				mList.add(m);

			}
			mylogger.info("All Details Displayed");
		} catch (SQLException e) {
			mylogger.error("No data Found");
			// e.printStackTrace();
			throw new MobileException("Data Not Found");

		} finally {
			try {
				pst.close();
				connect.close();

			} catch (SQLException e) {

				e.printStackTrace();
			}
		}

		return mList;
	}

	public boolean deleteRecord(int mobileId) throws MobileException {
		connect = JdbcUtil.getConnection();
		JdbcUtil j = new JdbcUtil();
		PropertyConfigurator.configure("log4j.properties");
		mylogger.info("deleterecord Method Started");
		int rec = 0;
		String query = "DELETE FROM mobiles WHERE mobileid=?";
		try {
			pst = connect.prepareStatement(query);
			pst.setInt(1, mobileId);
			rec = pst.executeUpdate();
			if (rec > 0) {
				mylogger.info("Record Deleted");
				return true;
			}

		} catch (SQLException e) {
			mylogger.error("Record not deleted");
			// e.printStackTrace();
			throw new MobileException("Data Not Deleted");
		} finally {
			try {
				pst.close();
				connect.close();

			} catch (SQLException e) {

				// e.printStackTrace();
			}
		}
		return false;
	}

	public List<Mobile> searchByRange(int low, int high) throws MobileException {
		connect = JdbcUtil.getConnection();
		JdbcUtil j = new JdbcUtil();
		PropertyConfigurator.configure("log4j.properties");
		mylogger.info("searchByRange Method Started");
		String query = "SELECT * FROM mobiles WHERE price>=? AND price<=?";
		List<Mobile> mList = new ArrayList<Mobile>();
		try {
			pst = connect.prepareStatement(query);
			pst.setInt(1, low);
			pst.setInt(2, high);
			ResultSet rst = pst.executeQuery();
			while (rst.next()) {
				int m_id = rst.getInt("MOBILEID");
				String m_name = rst.getString("NAME");
				double m_price = rst.getInt("PRICE");
				int m_qty = rst.getInt("QUANTITY");
				Mobile m = new Mobile();
				m.setMobileId(m_id);
				m.setMobileName(m_name);
				m.setPrice(m_price);
				m.setQuantity(m_qty);
				mList.add(m);

				mylogger.info("SearchByRange Successfull");
			}

		} catch (SQLException e) {
			mylogger.info("SearchByRange unsuccessful");
			e.printStackTrace();
			throw new MobileException("Data Not Found");
		} finally {
			try {
				pst.close();
				connect.close();

			} catch (SQLException e) {

				e.printStackTrace();
			}
		}

		return mList;
	}

	public boolean updateQuantity(int mobileId, int qty) throws MobileException {
		connect = JdbcUtil.getConnection();
		JdbcUtil j = new JdbcUtil();
		PropertyConfigurator.configure("log4j.properties");
		mylogger.info("updateQuantity Method Started");
		int quantity=0;
		String check = "SELECT QUANTITY FROM MOBILES WHERE mobileId=?";
		try {
			pst = connect.prepareStatement(check);
			pst.setInt(1, mobileId);
			ResultSet rst = pst.executeQuery();
			while (rst.next()) {
				quantity = rst.getInt("quantity");
			}
		} catch (SQLException e1) {

			e1.printStackTrace();
		}

		if (quantity > qty) {
			int record = 0;
			String query = "UPDATE mobiles SET quantity=quantity-? WHERE mobileId=?";
			try {

				pst = connect.prepareStatement(query);
				pst.setInt(1, qty);
				pst.setInt(2, mobileId);
				record = pst.executeUpdate();
				if (record > 0)
					return true;

				mylogger.info("Record Updated");

			} catch (SQLException e) {
				mylogger.info("Record not updated");
				// e.printStackTrace();
				throw new MobileException("Data is Not Updated");
			} finally {
				try {
					pst.close();
					connect.close();

				} catch (SQLException e) {

					e.printStackTrace();
				}

			}
		}else{
			System.out.println("Cannot Update. Quantity in stock is: "+quantity);
		}

		return false;
	}

	public boolean insertRecord(PurchaseDetails pd)	throws PurchaseDetailException, MobileException {
		
		JdbcUtil j = new JdbcUtil();
		PropertyConfigurator.configure("log4j.properties");
		connect = JdbcUtil.getConnection();
		mylogger.info("insertRecord Method Started");

		int rec = 0;
		int qty = 0;
		int count = 0;
		
		String idcheck = "SELECT COUNT(mobileId) FROM mobiles WHERE mobileId=?";
		String check = "SELECT quantity FROM mobiles WHERE mobileId=?";
		String query = "INSERT INTO purchasedetails VALUES(purchaseid_seq.NEXTVAL,?,?,?,sysdate,?)";
		
		String cname = pd.getCustomerName();
		String mailId = pd.getMailId();
		String phoneNo = pd.getPhoneNo();
		int mobileId = pd.getMobileId();
		
		try {
			pst = connect.prepareStatement(idcheck);
			pst.setInt(1, pd.getMobileId());
			ResultSet rst = pst.executeQuery();
			while (rst.next()) {
				count = rst.getInt(1);
			}
		} catch (SQLException e2) {

			e2.printStackTrace();
		}

		if (count == 1) {
			try {
				pst2 = connect.prepareStatement(check);
				pst2.setInt(1, mobileId);
				ResultSet rst = pst2.executeQuery();
				while (rst.next()) {
					qty = rst.getInt("quantity");

				}

				if (qty > 0) {
					pst = connect.prepareStatement(query);
					pst.setString(1, cname);
					pst.setString(2, mailId);
					pst.setString(3, phoneNo);
					pst.setInt(4, mobileId);
					rec = pst.executeUpdate();
					System.out.println("Record Inserted successfully.");
				} else {
					System.out.println("Existing Quantity: " + qty);
				}

				if (rec > 0) {
					return true;
				}

				mylogger.info("Record Inserted");

			} catch (SQLException e1) {

				// e1.printStackTrace();
				mylogger.error("Record not inserted ");
				throw new PurchaseDetailException("Invalid Input");

			} finally {
				try {
					pst.close();
					pst2.close();
					connect.close();
				} catch (SQLException e) {

					e.printStackTrace();
				}
			}
		} else {
			System.out.println("Invalid mobile id. Please enter valid one.\n");
			
		}
		
		return false;
	}

}


