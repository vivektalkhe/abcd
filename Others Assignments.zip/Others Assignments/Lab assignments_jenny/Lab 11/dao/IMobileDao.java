package com.cg.mobilesalesshop.dao;

import java.util.List;

import com.cg.mobilesalesshop.exception.MobileException;
import com.cg.mobilesalesshop.exception.PurchaseDetailException;
import com.cgmobilesalesshop.dto.Mobile;
import com.cgmobilesalesshop.dto.PurchaseDetails;

public interface IMobileDao {
	List<Mobile> showAllDetails() throws MobileException;
	boolean deleteRecord(int mobileId) throws MobileException;
	List<Mobile> searchByRange(int low,int high) throws MobileException;
	boolean updateQuantity(int mobileId, int qty)throws MobileException;
	
	boolean insertRecord(PurchaseDetails pd) throws PurchaseDetailException, MobileException;
	

}
