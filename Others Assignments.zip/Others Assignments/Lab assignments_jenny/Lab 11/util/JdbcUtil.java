package com.cg.mobilesalesshop.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import org.apache.log4j.Logger;
//import org.apache.log4j.PropertyConfigurator;

import com.cg.mobilesalesshop.exception.MobileException;

public class JdbcUtil {
	private static final Logger mylogger=
			Logger.getLogger(JdbcUtil.class);
	public static Properties loadProperties(){
		Properties prop = new Properties();
		InputStream input = null;
		try {
			input = new FileInputStream("oracle.properties");
			prop.load(input);
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		} catch (IOException e) {
			
			e.printStackTrace();
		}finally{
			try {
				input.close();
			} catch (IOException e) {
				
				e.printStackTrace();
			}
		}
		return prop;
		
	}
	
	public static Connection getConnection() throws MobileException{
		Connection connect = null;
		Properties prep = loadProperties();
		String url=prep.getProperty("oracle.url");
		String driver=prep.getProperty("oracle.driver");
		String user=prep.getProperty("oracle.uname");
		String password=prep.getProperty("oracle.upass");
		try {
			Class.forName(driver);
			mylogger.info("Driver is Loaded");
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
			mylogger.error("Driver is not loaded");
		}
		try {
			connect=DriverManager.getConnection(url, user, password);
			mylogger.info("Connected to the database.");
		} catch (SQLException e) {
			mylogger.error("Not Connected");
			throw new MobileException("Connection problem.");
			//e.printStackTrace();
		}
		return connect;
		
		
		
	}
	/*public static void main(String[] args){
		JdbcUtil j=new JdbcUtil();
		PropertyConfigurator.configure("log4j.properties");
		try {
			j.getConnection();
		} catch (MobileException e) {
			
			e.printStackTrace();
		}
	}*/
}
