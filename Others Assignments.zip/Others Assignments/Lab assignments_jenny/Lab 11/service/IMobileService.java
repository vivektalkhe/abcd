package com.cg.mobilesalesshop.service;

import java.util.List;

import com.cg.mobilesalesshop.exception.MobileException;
import com.cg.mobilesalesshop.exception.PurchaseDetailException;
import com.cgmobilesalesshop.dto.Mobile;
import com.cgmobilesalesshop.dto.PurchaseDetails;

public interface IMobileService {

	List<Mobile> showAllMobiles() throws MobileException;
	boolean deleteRecord(int mobileId) throws MobileException;
	List<Mobile> searchMobile(int low,int high) throws MobileException;
	boolean updateQuantity(int mobileId, int qty)throws MobileException;
	boolean insertRecord(PurchaseDetails pd) throws PurchaseDetailException, MobileException;
	
}
	
