package com.cg.mobilesalesshop.service;

import java.util.List;

import com.cg.mobilesalesshop.dao.IMobileDao;
import com.cg.mobilesalesshop.dao.MobileDaoImpl;
import com.cg.mobilesalesshop.exception.MobileException;
import com.cg.mobilesalesshop.exception.PurchaseDetailException;
import com.cgmobilesalesshop.dto.Mobile;
import com.cgmobilesalesshop.dto.PurchaseDetails;

public class MobileServiceImpl implements IMobileService {

	IMobileDao imobile = new MobileDaoImpl();
	
	public List<Mobile> showAllMobiles() throws MobileException {
		
		return imobile.showAllDetails();
	}

	public boolean deleteRecord(int mobileId) throws MobileException {
		
		return imobile.deleteRecord(mobileId);
	}

	public List<Mobile> searchMobile(int low, int high) throws MobileException {
		
		return imobile.searchByRange(low, high);
	}

	public boolean updateQuantity(int mobileId, int qty) throws MobileException {
		
		return imobile.updateQuantity(mobileId, qty);
	}

	public List<Mobile> searchByPurchaseId(int purchaseId)
			throws MobileException {
		
		return null;
	}

	public boolean insertRecord(PurchaseDetails pd)	throws PurchaseDetailException, MobileException {
		
		return imobile.insertRecord(pd);
	}

}
