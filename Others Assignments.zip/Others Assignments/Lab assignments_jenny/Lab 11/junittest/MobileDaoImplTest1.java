package com.cg.mobilesalesshop.junittest;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;

import com.cg.mobilesalesshop.dao.IMobileDao;
import com.cg.mobilesalesshop.dao.MobileDaoImpl;
import com.cg.mobilesalesshop.exception.MobileException;

public class MobileDaoImplTest1 {
	IMobileDao iMobile;

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setup() {
		iMobile = new MobileDaoImpl();
	}

	@Test
	public void testShowAllDetails() throws MobileException {
		assertNotNull(iMobile.showAllDetails());
	}

	@After
	public void tearDown() {
		iMobile = null;
	}

}
