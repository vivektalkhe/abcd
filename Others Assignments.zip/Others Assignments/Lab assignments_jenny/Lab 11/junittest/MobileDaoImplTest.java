package com.cg.mobilesalesshop.junittest;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;

import com.cg.mobilesalesshop.dao.IMobileDao;
import com.cg.mobilesalesshop.dao.MobileDaoImpl;
import com.cg.mobilesalesshop.exception.MobileException;
import com.cg.mobilesalesshop.exception.PurchaseDetailException;
import com.cgmobilesalesshop.dto.PurchaseDetails;

public class MobileDaoImplTest {

	IMobileDao iMobile;
	PurchaseDetails pd;

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setup() {
		iMobile = new MobileDaoImpl();
		pd = new PurchaseDetails();
	}

	@Test
	public void testInsertRecord() throws PurchaseDetailException,
			MobileException {

		pd.setCustomerName("Lucifer");
		pd.setMailId("abc@gmail.com");
		pd.setMobileId(1003);
		pd.setPhoneNo("0798678");

		boolean flag = iMobile.insertRecord(pd);
		assertTrue("Rec inserted", flag);

	}

	@After
	public void tearDown() {
		iMobile = null;
	}

}
