package com.cg.mobilesalesshop.ui;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.mobilesalesshop.dao.MobileDaoImpl;
import com.cg.mobilesalesshop.exception.MobileException;
import com.cg.mobilesalesshop.exception.PurchaseDetailException;
import com.cg.mobilesalesshop.service.IMobileService;
import com.cg.mobilesalesshop.service.MobileServiceImpl;
import com.cg.mobilesalesshop.util.JdbcUtil;
import com.cgmobilesalesshop.dto.Mobile;
import com.cgmobilesalesshop.dto.PurchaseDetails;

public class MobileSalesShopApplication {
	private static final Logger mylogger = Logger.getLogger(JdbcUtil.class);

	public static void main(String[] args) {

		JdbcUtil j = new JdbcUtil();
		PropertyConfigurator.configure("log4j.properties");
		mylogger.info("Application Started");

		
		IMobileService ims = new MobileServiceImpl();
		PurchaseDetails pd = new PurchaseDetails();
		String cust_name;
		String cust_email;
		String cust_phone;
		String cust_mobileid;
		boolean name;
		boolean mailid;
		boolean phone;
		boolean mobileid;
		int idmobile;
		int choice;
		int quantity;
		String mobile;
		Scanner sc = new Scanner(System.in);
		do {
			System.out.println("Mobile Sales Shop");
			System.out.println("Select the operation you want to perform:");
			System.out.println("1. Insert the customer purchase details. ");
			System.out.println("2. Update the quantity.");
			System.out.println("3. Show all details.");
			System.out.println("4. Delete mobile record.");
			System.out.println("5. Search mobiles based on price range.");
			System.out.println("6. Exit.");
			System.out.println("Enter your choice: ");
			choice = sc.nextInt();
			switch (choice) {
			case 1:
				System.out.println("Enter customer name:");
				cust_name = sc.next();
				name = Pattern.matches("[A-Z]{1}[a-z]{1,19}", cust_name);
				do {
					if (name == false) {
						System.out.println("Enter valid name");
						System.out.println("Enter name again:");
						cust_name = sc.next();
						name = Pattern.matches("[A-Z]{1}[a-z]{1,19}", cust_name);
					}
				} while (name == false);
				System.out.println("Enter customer email:");
				cust_email = sc.next();
				mailid = Pattern.matches("^(.+)@(.+)[.]{1}(.+)$", cust_email);
				do {
					if (mailid == false) {
						System.out.println("Enter valid email");
						System.out.println("Enter mailid again:");
						cust_email = sc.next();
						mailid = Pattern.matches("^(.+)@(.+)[.]{1}(.+)$",
								cust_name);
					}
				} while (mailid == false);
				System.out.println("Enter customer phone no:");
				cust_phone = sc.next();
				phone = Pattern.matches("[7|8|9]{1}[0-9]{9}", cust_phone);
				do {
					if (phone == false) {
						System.out.println("Enter valid phone no");
						System.out.println("Enter phone no again:");
						cust_phone = sc.next();
						phone = Pattern.matches("[7|8|9]{1}[0-9]{9}",
								cust_phone);
					}
				} while (phone == false);
				System.out.println("Enter customer mobile id:");
				mobile = sc.next();
				mobileid = Pattern.matches("[1-9]{1}[0-9]{3}", mobile);
				do {
					if (mobileid == false) {
						System.out.println("Enter valid mobile id");
						System.out.println("Enter customer mobile id again:");
						mobile = sc.next();
						mobileid = Pattern.matches("[1-9]{1}[0-9]{3}", mobile);
					}
				} while (phone == false);
				idmobile = Integer.parseInt(mobile);
				System.out.println("Enter the quantity of mobiles purchased:");
				quantity=sc.nextInt();
				do{
					if(quantity <= 0){
						System.out.println("Quantity should be greater than zero.");
					}
				}while(quantity <= 0);
				pd.setCustomerName(cust_name);
				pd.setMailId(cust_email);
				pd.setMobileId(idmobile);
				pd.setPhoneNo(cust_phone);

				try {
					ims.insertRecord(pd);
					MobileDaoImpl update=new MobileDaoImpl();
					update.updateQuantity(idmobile, quantity);
				} catch (PurchaseDetailException e2) {

					e2.printStackTrace();
				} catch (MobileException e2) {

					e2.printStackTrace();
				}

				break;
			case 2:

				int id;
				int qty;
				System.out.println("Update Records");
				System.out.println("Enter the mobile id: ");
				id = sc.nextInt();
				System.out.println("Enter the quantity: ");
				qty = sc.nextInt();
				try {
					ims.updateQuantity(id, qty);
				} catch (MobileException e) {

					e.printStackTrace();
				}
				break;
			case 3:
				try {
					List<Mobile> mList = ims.showAllMobiles();
					for (Mobile m : mList) {
						System.out.println(m);
					}
				} catch (MobileException e1) {

					e1.printStackTrace();
				}

				break;
			case 4:
				System.out.println("Delete Records");
				System.out.println("Enter the mobile id: ");
				id = sc.nextInt();
				try {
					ims.deleteRecord(id);
				} catch (MobileException e) {

					e.printStackTrace();
				}
				break;
			case 5:
				System.out.println("Enter the price range:");
				System.out.println("Enter the low range:");
				int low = sc.nextInt();
				System.out.println("Enter the high range:");
				int high = sc.nextInt();
				try {
					List<Mobile> mList = ims.searchMobile(low, high);
					for (Mobile m : mList) {
						System.out.println(m);
					}
				} catch (MobileException e) {

					e.printStackTrace();
				}
				break;
			case 6:
				System.out.println("Ta Da...!!!!! Come Again!!!");
				System.exit(0);
				break;
			default:
				System.out.println("Invalid Choice");
				break;

			}
		} while (choice != 6);
		sc.close();
		mylogger.info("Application ended");
	}

}
