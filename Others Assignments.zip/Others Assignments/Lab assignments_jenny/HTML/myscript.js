//myscript

function popMovie()
{
	//alert("inside");
	var x=document.form1.language.selectedIndex;
	alert(x);
	if(x==0)
	{
		var no = new option();
		no.value="XXX";
		no.text="Titanic";
		document.form1.movie.options[0]=no;
		
		var no1 = new option();
		no1.value="janam samjha karo";
		no1.text="Dil hai Tumhara";
		document.form1.movie.options[1]=no1;
		
		var no2 = new option();
		no2.value="sairat";
		no2.text="Lay bhari";
		document.form1.movie.options[2]=no2;
	}
}