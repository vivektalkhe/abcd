import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;


public class UserDates {

	public static void calculateDuration(String udate1, String udate2){
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		LocalDate userDate = LocalDate.parse(udate1,formatter);
		System.out.println(" Given User Date1 "+udate1);
		LocalDate userDate1 = LocalDate.parse(udate2,formatter);
		System.out.println(" Given User Date2 "+udate2);
		Period duration = userDate.until(userDate1);
		
		System.out.println("Days "+duration.getDays()+" Months "
				+duration.getMonths()+" year "+duration.getYears());
	}
	public static void main(String[] args) {
		String stringDate;
		String userDate;
		System.out.println("Enter first date:");
		Scanner sc = new Scanner(System.in);
		stringDate=sc.nextLine();
		System.out.println("Enter second date:");
		Scanner sd = new Scanner(System.in);
		userDate=sd.nextLine();
		calculateDuration(stringDate,userDate);
		sc.close();
		sd.close();

	}

}
