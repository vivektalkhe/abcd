import java.util.Scanner;


public class PositiveString {

	public static void main(String[] args) {
		String newString;
		System.out.println("Enter the string");
		Scanner sc = new Scanner(System.in);
		newString=sc.nextLine();
		orderString(newString);
		
		sc.close();

	}
	
	public static void orderString(String newString){
		int length=newString.length();
		int count=0;
		for(int i=0;i<length-1;i++){
			if((int)newString.charAt(i)<(int)newString.charAt(i+1)){
				count++;
				
			}else{
				count=0;
			}
		}
		if(count==length-1){
			System.out.println("Entered String is Positive");
		}else{
			System.out.println("Entered String is Negative");
		}
	}

}

