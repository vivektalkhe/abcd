import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Scanner;


public class UserTimeZone {
	
	public static void zoneId(String stringZone){
		ZonedDateTime zdt = ZonedDateTime.now(ZoneId.of(stringZone));
		System.out.println(zdt);
	}

	public static void main(String[] args) {
		
		String stringZone;
		System.out.println("Enter Zone ID:");
		Scanner sc = new Scanner(System.in);
		stringZone=sc.nextLine();
		zoneId(stringZone);
		sc.close();

	}

}
