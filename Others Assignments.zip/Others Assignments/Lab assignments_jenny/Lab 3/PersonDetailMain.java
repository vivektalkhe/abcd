import java.util.Scanner;


public class PersonDetailMain {

	public static void main(String[] args) {
		Gender gender=null;
		PersonDetails persondetail = new PersonDetails();
		
				
		Scanner sc1 = new Scanner(System.in);
		System.out.println("Enter firstname");
		String firstname = sc1.nextLine();
		persondetail.setFirstName(firstname);
		
		Scanner sc2 = new Scanner(System.in);
		System.out.println("Enter last name");
		String lastname = sc2.nextLine();
		persondetail.setLastName(lastname);
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter gender");
		String p_gender = sc.nextLine();
		gender=Gender.valueOf(p_gender);
		persondetail.setGender(gender);
		
		System.out.println("Enter date of birth");
		String dob = sc.nextLine();
		persondetail.setDateOfBirth(dob);
		
		
		System.out.println("Enter phone number");
		String phn = sc.nextLine();
		persondetail.setPhn(phn);
		
		
		sc.close();
		sc1.close();
		sc2.close();
		persondetail.calculateAge(dob);
		persondetail.getFullName(firstname, lastname);
		persondetail.display();
	}

}
