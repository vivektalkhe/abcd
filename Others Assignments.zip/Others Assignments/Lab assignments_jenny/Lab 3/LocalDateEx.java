import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;


public class LocalDateEx {
	
	public static void calculatePeriod(String sdate){
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		LocalDate givenDate = LocalDate.parse(sdate,formatter);
		System.out.println(" Given Date "+givenDate);
		LocalDate today=LocalDate.now();
		System.out.println(" Today "+today);
		Period period = givenDate.until(today);
		
		System.out.println("Days "+period.getDays()+" Months "
							+period.getMonths()+" year "+period.getYears());
	}

	public static void main(String[] args) {
		String stringDate;
		Scanner sc = new Scanner(System.in);
		stringDate=sc.nextLine();
		calculatePeriod(stringDate);
		sc.close();

	}

}
