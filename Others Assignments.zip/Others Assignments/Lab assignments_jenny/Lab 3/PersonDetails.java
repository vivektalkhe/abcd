import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;


public class PersonDetails {

	String firstName;
	String lastName;
	String dateOfBirth;
	Gender gender;
	String phn;
	int age;
	
	
	public PersonDetails() {
		super();
	}

	
	
	public PersonDetails(String firstName, String lastName, String dateOfBirth,
			Gender gender, String phn, int age) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.dateOfBirth = dateOfBirth;
		this.gender = gender;
		this.phn = phn;
		this.age = age;
	}




	
	public String getFirstName() {
		return firstName;
	}



	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}



	public String getLastName() {
		return lastName;
	}



	public void setLastName(String lastName) {
		this.lastName = lastName;
	}



	public String getDateOfBirth() {
		return dateOfBirth;
	}



	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}



	public Gender getGender() {
		return gender;
	}



	public void setGender(Gender gender) {
		this.gender = gender;
	}



	public String getPhn() {
		return phn;
	}



	public void setPhn(String phn) {
		this.phn = phn;
	}



	public int getAge() {
		return age;
	}



	public void setAge(int age) {
		this.age = age;
	}



	void calculateAge(String dob){
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		LocalDate userDate = LocalDate.parse(dob,formatter);
		LocalDate today=LocalDate.now();
		Period period = userDate.until(today);
		age=period.getYears();
	}
	
	void getFullName(String firstName,String lastName){
		System.out.println("               ");
		System.out.println("               ");		
		System.out.println("Person Details:");
		System.out.println("_______________");
		System.out.println("               ");
		String fullName=firstName+" "+lastName;
		System.out.println("Fullname is: "+fullName);
	}
	
	
	void display(){
		
		System.out.println("Gender:"+gender);
		System.out.println("Age:"+age);
		System.out.println("Phone number:"+phn);
	}
	
}
