package com.cg.mobileapp.service;

import java.util.List;
import java.util.regex.Pattern;

import com.cg.mobileapp.exceptions.MobileAppException;
import com.cg.mobileapp.dao.MobileAppDAOImpl;
import com.cg.mobileapp.dao.MobileAppDAOInterface;
import com.cg.mobileapp.dto.Mobile;
import com.cg.mobileapp.dto.PurchaseDetails;
import com.cg.mobileapp.exceptions.MobileAppException;

public class MobileAppServiceImpl implements MobileAppInterface{
	
	MobileAppDAOInterface imobile=new MobileAppDAOImpl();
	@Override
	public List<Mobile> showAllMobiles() throws MobileAppException {
		// TODO Auto-generated method stub
		return imobile.showAll();
	}

	@Override
	public boolean deleteMobiledata(int mobileId) throws MobileAppException {
		// TODO Auto-generated method stub
		return imobile.deleteMobile(mobileId);
	}

	@Override
	public List<Mobile> searchByRange(int start, int end)
			throws MobileAppException {
		// TODO Auto-generated method stub
		return imobile.searchByPriceRange(start, end);
	}

	@Override
	public boolean reduceQuantityDetails(int mobileid, int quantity)
			throws MobileAppException {
		
		return imobile.updateQuantityDetails(mobileid, quantity);
	}

	@Override
	public boolean insertPurchaseDetails(PurchaseDetails purchaseDetails)
			throws MobileAppException {
		// TODO Auto-generated method stub
		return imobile.insertPurchaseDetails(purchaseDetails);
	}
	public static void validateName
	(String patt,String name) throws MobileAppException{
	boolean value=Pattern.matches(patt,name);
	if(!value){
		throw new MobileAppException("Name should be max 20 letters and First letter should be capital");
	}
		
	}
	public static void validateMail
	(String patt,String name) throws MobileAppException{
	boolean value=Pattern.matches(patt,name);
	if(!value){
		throw new MobileAppException("Enter valid mailId");
	}
		
	}
	public static void validatePhone
	(String patt,String name) throws MobileAppException{
	boolean value=Pattern.matches(patt,name);
	if(!value){
		throw new MobileAppException("Enter valid Phone Number");
	}
		
	}
	public static void validateMobileId	(String patt,String name) throws MobileAppException{
	boolean value=Pattern.matches(patt,name);
	if(!value){
		throw new MobileAppException("Enter valid Mobile Id");
	}
		
	}

	@Override
	public List<PurchaseDetails> showAllPurchaseServ()
			throws MobileAppException {
		// TODO Auto-generated method stub
		return imobile.showAllPurchase();
	}

}
