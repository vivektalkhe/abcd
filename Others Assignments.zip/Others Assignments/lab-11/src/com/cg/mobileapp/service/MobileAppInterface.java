package com.cg.mobileapp.service;

import java.util.List;

import com.cg.mobileapp.dto.Mobile;
import com.cg.mobileapp.dto.PurchaseDetails;
import com.cg.mobileapp.exceptions.MobileAppException;

interface MobileAppInterface {
	
	boolean reduceQuantityDetails(int mobileid,int quantity)throws MobileAppException;
	List<Mobile> showAllMobiles()throws MobileAppException;
	boolean deleteMobiledata(int mobileId)throws MobileAppException;
	List<Mobile> searchByRange(int start, int end)throws MobileAppException;
	boolean insertPurchaseDetails(PurchaseDetails purchaseDetails) throws MobileAppException;
	public List<PurchaseDetails> showAllPurchaseServ() throws MobileAppException;


}
