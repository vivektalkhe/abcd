package com.cg.mobileapp.testcases;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.mobileapp.dao.*;
import com.cg.mobileapp.exceptions.MobileAppException;
public class TestMobileDaoImpl {

	MobileAppDAOInterface imobile;
	@Before
	public void setUp() throws Exception {
		imobile=new MobileAppDAOImpl();
	}

	@After
	public void tearDown() throws Exception {
		imobile=null;
	}

	@Test
	public void testShowAll() {
		
		try {
			assertNotNull(imobile.showAll());
		} catch (MobileAppException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Test
	public void testShowAllPurchase(){
		
		try {
			assertNotNull(imobile.showAllPurchase());
		} catch (MobileAppException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
