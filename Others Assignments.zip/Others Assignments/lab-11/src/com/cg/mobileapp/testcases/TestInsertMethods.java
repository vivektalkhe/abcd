package com.cg.mobileapp.testcases;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.cg.mobileapp.dao.MobileAppDAOImpl;
import com.cg.mobileapp.dto.PurchaseDetails;
import com.cg.mobileapp.exceptions.MobileAppException;

public class TestInsertMethods {
	MobileAppDAOImpl imobile=new MobileAppDAOImpl();
	PurchaseDetails purchase;
	@Before
	public void setUp() throws Exception {
	
		java.sql.Date sqlDate = new java.sql.Date(new java.util.Date().getTime());
		purchase=new PurchaseDetails(202,"Pranav","prn@dhanu","9879898978",1002);

		purchase.setPurchaseDate(sqlDate);
	
		
	}

	@After
	public void tearDown() throws Exception {
		//imobile=null;
		
	}

	@Test
	public void test() {
		try {
		
			Assert.assertTrue(imobile.insertPurchaseDetails(purchase));
		} catch (MobileAppException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Test
	public void testDelete(){
		try {
			assertTrue(imobile.deleteMobile(purchase.getMobileId()));
		} catch (MobileAppException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
