package com.cg.mobileapp.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;

import com.cg.mobileapp.dto.Mobile;
import com.cg.mobileapp.dto.PurchaseDetails;
import com.cg.mobileapp.exceptions.MobileAppException;
import com.cg.mobileapp.ui.MobileApplication;
import com.cg.mobileapp.util.JDBCUtil;

public class MobileAppDAOImpl implements MobileAppDAOInterface {

	Connection con = null;
	PreparedStatement pst = null;
	private static final Logger mylogger=Logger.getLogger(MobileApplication.class);
	@Override
	public boolean insertPurchaseDetails(PurchaseDetails purchaseDetails)throws MobileAppException {
	
		boolean flag=validateMobileId(purchaseDetails.getMobileId());
		java.sql.Date sqlDate = new java.sql.Date(new java.util.Date().getTime());
		if (flag) {
			try {
				con = JDBCUtil.getConnection();
			} catch (MobileAppException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			String insertQuery = "insert into purchasedetails values(?,?,?,?,?,?)";
			try {
				pst = con.prepareStatement(insertQuery);
				pst.setInt(1, getPurchaseId());
				pst.setString(2, purchaseDetails.getCust_name());
				pst.setString(3, purchaseDetails.getMailId());
				pst.setString(4, purchaseDetails.getPhoneNo());
				pst.setDate(5,	sqlDate);
				pst.setInt(6, purchaseDetails.getMobileId());

				int c = pst.executeUpdate();
				if (c > 0) {
					System.out.println("data successfully inserted");
					updateQuantityDetails(purchaseDetails.getMobileId(), 1);
					return true;
				}else{
					mylogger.error("Data Not inserted");
				}

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				try {
					pst.close();
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

		}else{
			throw new MobileAppException("Invalid Mobile Id");
		}

		return false;
	}

	@Override
	public boolean updateQuantityDetails(int mobileid, int quantity) {

		try {
			con = JDBCUtil.getConnection();
		} catch (MobileAppException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		String updateQuery = "update mobiles set quantity=quantity-'"
				+ quantity + "' where mobileid='" + mobileid + "'";
		try {
			pst = con.prepareStatement(updateQuery);
			int c = pst.executeUpdate();
			if (c > 0)
				return true;

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		return false;
	}

	@Override
	public List<Mobile> showAll() throws MobileAppException {

		List<Mobile> moblist = new ArrayList<Mobile>();
		con = JDBCUtil.getConnection();
		String displayQuery = "select * from mobiles";
		try {
			pst = con.prepareStatement(displayQuery);
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {

				int mid = rs.getInt(1);
				String name = rs.getString(2);
				double price = rs.getDouble(3);
				int qty = rs.getInt(4);
				Mobile mob = new Mobile(mid, name, price, qty);
				moblist.add(mob);
			}

		} catch (SQLException e) {

			e.printStackTrace();
			throw new MobileAppException("Data Not Found");

		} finally {
			try {
				pst.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				
			}

		}
		return moblist;

	}

	@Override
	public boolean deleteMobile(int mobileId) throws MobileAppException {
		con = JDBCUtil.getConnection();
		String deleteQuery = "delete from mobiles where mobileid='" + mobileId
				+ "'";
		try {
			pst = con.prepareStatement(deleteQuery);
			int c = pst.executeUpdate();
			if (c > 0)
				return true;

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				con.close();
			} catch (SQLException e) {

				e.printStackTrace();
				throw new MobileAppException("Data Not Deleted");
			}

		}

		return false;
	}

	@Override
	public List<Mobile> searchByPriceRange(int start, int end)
			throws MobileAppException {

		List<Mobile> moblist = new ArrayList<Mobile>();
		con = JDBCUtil.getConnection();
		String searchQuery = "select * from mobiles where price >= ? AND price <= ?";
		try {
			pst = con.prepareStatement(searchQuery);
			pst.setDouble(1, start);
			pst.setDouble(2, end);
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {

				int mid = rs.getInt(1);
				String name = rs.getString(2);
				double price = rs.getDouble(3);
				int qty = rs.getInt(4);
				Mobile mob = new Mobile(mid, name, price, qty);
				moblist.add(mob);

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

			throw new MobileAppException("Data Not Found in that range");
		} finally {
			try {
				pst.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		return moblist;
	}

	public static int getPurchaseId() {
		int id = 0;
		String query = "SELECT PURCHASE_id.NEXTVAL FROM DUAL";
		Connection conn = null;
		PreparedStatement pstm = null;

		try {
			conn = JDBCUtil.getConnection();
			pstm = conn.prepareStatement(query);
			ResultSet res = pstm.executeQuery();
			while (res.next()) {
				id = res.getInt(1);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (MobileAppException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				pstm.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		return id;

	}

	public static boolean validateMobileId(int mobId) {
		int id = 0;
		String query = "SELECT mobileid FROM mobiles";
		Connection conn = null;
		PreparedStatement pstm = null;

		try {
			conn = JDBCUtil.getConnection();
			pstm = conn.prepareStatement(query);
			ResultSet res = pstm.executeQuery();
			while (res.next()) {
				id = res.getInt(1);
				if (id == mobId) {
					
					return true;
				}

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (MobileAppException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				pstm.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		return false;

	}

	@Override
	public List<PurchaseDetails> showAllPurchase() throws MobileAppException {

		List<PurchaseDetails> moblist = new ArrayList<PurchaseDetails>();
		con = JDBCUtil.getConnection();
		String displayQuery = "select * from purchasedetails";
		try {
			pst = con.prepareStatement(displayQuery);
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {

				int mid = rs.getInt(1);
				String cname = rs.getString(2);
				String mail=rs.getString(3);
				String phone=rs.getString(4);
				java.sql.Date pdate=rs.getDate(5);
				int mobid=rs.getInt(6);
				PurchaseDetails mob = new PurchaseDetails(mid,cname,mail,phone,mobid);
				mob.setPurchaseDate(pdate);
				moblist.add(mob);
			}

		} catch (SQLException e) {

			e.printStackTrace();
			throw new MobileAppException("Data Not Found");

		} finally {
			try {
				pst.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		return moblist;

	}

}
