package com.cg.mobileapp.dao;

import java.util.List;

import com.cg.mobileapp.dto.*;
import com.cg.mobileapp.exceptions.MobileAppException;

public interface MobileAppDAOInterface {
	
	boolean insertPurchaseDetails(PurchaseDetails purchaseDetails) throws MobileAppException;
	boolean updateQuantityDetails(int mobileid,int quantity)throws MobileAppException;
	
	List<Mobile> showAll()throws MobileAppException;
	boolean deleteMobile(int mobileId)throws MobileAppException;
	List<Mobile> searchByPriceRange(int start, int end)throws MobileAppException;
	public List<PurchaseDetails> showAllPurchase() throws MobileAppException;
}
