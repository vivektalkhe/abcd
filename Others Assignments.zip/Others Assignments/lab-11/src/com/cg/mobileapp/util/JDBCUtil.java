package com.cg.mobileapp.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.mobileapp.exceptions.MobileAppException;
import com.cg.mobileapp.util.JDBCUtil;

public class JDBCUtil {
	
	private static final Logger mylogger=Logger.getLogger(JDBCUtil.class);
	
	public static Properties getProperty1(){
		Properties prop=new Properties();
		InputStream in=null;
		
		try {
			in=new FileInputStream("oracle.properties");
			prop.load(in);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
			
		 catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			try {
				in.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return prop;
		
	}
	
	public static Connection getConnection() throws MobileAppException{
		Connection con=null;
		//Properties prop=new Properties();
		
		Properties prop=JDBCUtil.getProperty1();
		String driver =prop.getProperty("oracle.driver");
		String url=prop.getProperty("oracle.url");
		String uname=prop.getProperty("oracle.uname");
		String pwd=prop.getProperty("oracle.upass");
		
		
		try {
			Class.forName(driver);
			mylogger.info("Driver is loaded");
			con=DriverManager.getConnection(url,uname,pwd);
			mylogger.info("Connection established to the  database");
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			mylogger.error("Driver is not loaded");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			mylogger.error("Not connected");
			throw new MobileAppException("Connection not established");
		}
		
		
		return con;
		
	}
/*	public static void main(String[] args) {
		JDBCUtil j=new JDBCUtil();
		PropertyConfigurator.configure("log4j.properties");
		try {
			Connection con=j.getConnection();
			if(con!=null)
			System.out.println("sdgh");
		} catch (MobileAppException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}*/

}
