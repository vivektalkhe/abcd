package com.cg.mobileapp.ui;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import java.util.regex.PatternSyntaxException;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.mobileapp.dao.MobileAppDAOImpl;
import com.cg.mobileapp.dto.Mobile;
import com.cg.mobileapp.dto.PurchaseDetails;
import com.cg.mobileapp.exceptions.MobileAppException;
import com.cg.mobileapp.service.MobileAppServiceImpl;
import com.cg.mobileapp.util.JDBCUtil;

public class MobileApplication {

	private static final Logger mylogger=Logger.getLogger(MobileApplication.class);
	private static int choice;

	// private static Date today;

	public static void main(String[] args) {

		//PropertyConfigurator.configure("log4j.properties");
		mylogger.info("Application started");
		
		Scanner sc=new Scanner(System.in);
		LocalDate today = LocalDate.now();
		MobileAppServiceImpl ps = new MobileAppServiceImpl();
		System.out.println(today);
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		try {
			do {
				printChoice();
				
				choice = sc.nextInt();
				switch (choice) {

				case 1:
					System.out.println("Enter the customer name: ");
					String cname = br.readLine();
					String patt="^[A-Z].[A-Za-z[\\s]]{2,20}$";
					try{
					ps.validateName(patt, cname);
					}catch (MobileAppException e) {
						mylogger.error("User has entered invalid name");
						System.out.println(e.getMessage());
						break;
					}
					System.out.println("Enter the mailid");
					String mail = br.readLine();
					String patt1="^(.+)@(.+)$";
					try{
						ps.validateMail(patt1, mail);
					}catch(MobileAppException e){
						mylogger.error("User entered invalid mail id");
						System.out.println(e.getMessage());
						break;
					}
					
					System.out.println("Enter the phone no");
					String mob = br.readLine();
					String patt2="^[7-9][0-9]{9}$";

					try{
						ps.validatePhone(patt2, mob);
					}catch(MobileAppException e){
						mylogger.error("User entered invalid phone number");
						System.out.println(e.getMessage());
						break;
					}
					System.out.println("Enter the mobileId");
					int mid = Integer.parseInt(br.readLine());
					
					PurchaseDetails per = new PurchaseDetails();
					per.setCust_name(cname);
					per.setMailId(mail);
					per.setMobileId(mid);
					per.setPhoneNo(mob);

					
					ps.insertPurchaseDetails(per);
					mylogger.info("Data is successfully Inserted");
					System.out.println("Data is inserted");

					break;
				case 2:
					List<Mobile> mobList=ps.showAllMobiles();
					for(Mobile mobtemp:mobList){
							System.out.println("Mobile Id="+mobtemp.getMobileId());
							System.out.println("Mobile name= "+mobtemp.getMobName());
							System.out.println("Mobile price ="+mobtemp.getPrice());
							System.out.println("Quantity = "+mobtemp.getQuantity());
					}
					break;
				case 3:
					System.out.println("Enter the starting price");
					int start=(int) Double.parseDouble(br.readLine());
					System.out.println("Enter the end price");
					int end=(int) Double.parseDouble(br.readLine());
					List<Mobile> mobList1=ps.searchByRange(start, end);
					for(Mobile mobtemp:mobList1){
							System.out.println("Mobile Id="+mobtemp.getMobileId());
							System.out.println("Mobile name= "+mobtemp.getMobName());
							System.out.println("Mobile price ="+mobtemp.getPrice());
							System.out.println("Quantity = "+mobtemp.getQuantity());
					}
					break;
				case 4:
					System.out.println("Enter the mobile Id :");
					int idm=Integer.parseInt(br.readLine());
					if(ps.deleteMobiledata(idm)){
						System.out.println("Data is deleted");
					}
					else{
						System.out.println("Enter the valid Mobile Id...Id does not exist");
					}
					break;
				case 5:
					//System.out.println(ps.showAllPurchaseServ());
					List<PurchaseDetails> plist=ps.showAllPurchaseServ();
					for(PurchaseDetails p:plist){
						System.out.println("Mobile Id="+p.getCust_name());
						System.out.println("Mobile name= "+p.getMailId());
						System.out.println("Mobile price ="+p.getMobileId());
						System.out.println("Quantity = "+p.getPhoneNo());
						System.out.println(p.getPurchaseId());
						System.out.println(p.getPurchaseDate());
					}
				case 6: 
					System.exit(0);
					default:
						System.out.println("Enter the valid Choice.............");
				}

			} while (choice != 6);

		} catch (NumberFormatException e) {
			mylogger.error("Wrong choice is made");
			e.printStackTrace();
		} catch (IOException e) {
			
			e.printStackTrace();
		} catch (MobileAppException e) {
			
			System.out.println(e.getMessage());
		}
		catch(PatternSyntaxException e){
			System.out.println(e);
		}
	}

	public static void printChoice() {

		System.out.println("**************************Mobile Application********************************");
		System.out.println("1. Purchase new Mobile ");
		System.out.println("2. Show All Mobiles");
		System.out.println("3. Show Mobiles in specific Range");
		System.out.println("4. Delete Mobile entry");
		System.out.println("5. Show purchase details ");
		System.out.println("6. Exit");
		System.out
				.println("****************************************************************************");
		System.out.println("Enter the choice");
	}
}
