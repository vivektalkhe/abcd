package com.cg.mobileapp.exceptions;

public class MobileAppException extends Exception {
	
	public MobileAppException(String msg) {
		super(msg);
	}

}
