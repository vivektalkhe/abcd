package com.cg.mobileapp.dto;

public class Mobile {
	private int mobileId;
	private String mobName;
	private double price;
	private int quantity;
	
	
	public Mobile() {
	
	}
	public Mobile(int mobileId, String mobName, double price, int quantity) {
		super();
		this.mobileId = mobileId;
		this.mobName = mobName;
		this.price = price;
		this.quantity = quantity;
	}
	public int getMobileId() {
		return mobileId;
	}
	public String getMobName() {
		return mobName;
	}
	public double getPrice() {
		return price;
	}
	public int getQuantity() {
		return quantity;
	}
	@Override
	public String toString() {
		return "Mobile [mobileId=" + mobileId + ", mobName=" + mobName
				+ ", price=" + price + ", quantity=" + quantity + "]";
	}
	
	 

}
