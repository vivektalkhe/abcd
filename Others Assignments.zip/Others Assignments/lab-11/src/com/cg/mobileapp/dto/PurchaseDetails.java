package com.cg.mobileapp.dto;

import java.sql.Date;



public class PurchaseDetails {
private int purchaseId;
private String cust_name;
private String phoneNo;
private Date purchaseDate;
private String mailId;
private int mobileId;
public PurchaseDetails() {
	// TODO Auto-generated constructor stub
}
public PurchaseDetails(int purchaseId, String cust_name, String phoneNo,
		 String mailId,int mobileId) {
	super();
	this.purchaseId = purchaseId;
	this.cust_name = cust_name;
	this.phoneNo = phoneNo;
	this.purchaseDate = purchaseDate;
	this.mailId = mailId;
	this.mobileId=mobileId;
}
public int getPurchaseId() {
	return purchaseId;
}
public String getCust_name() {
	return cust_name;
}
public String getPhoneNo() {
	return phoneNo;
}
public Date getPurchaseDate() {
	return purchaseDate;
}
public String getMailId() {
	return mailId;
}


public int getMobileId() {
	return mobileId;
}
public void setMobileId(int mobileId) {
	this.mobileId = mobileId;
}
public void setPurchaseId(int purchaseId) {
	this.purchaseId = purchaseId;
}
public void setCust_name(String cust_name) {
	this.cust_name = cust_name;
}
public void setPhoneNo(String phoneNo) {
	this.phoneNo = phoneNo;
}
public void setPurchaseDate(Date purchaseDate) {
	this.purchaseDate = purchaseDate;
}
public void setMailId(String mailId) {
	this.mailId = mailId;
}


}
