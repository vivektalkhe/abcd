package com.cg.ma.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import org.apache.log4j.Logger;


import com.cg.ma.execption.MobileException;



public class JdbcUtil {

	private static final Logger myLogger= Logger.getLogger(JdbcUtil.class);
	
	static Connection con=null;
	public static Properties loadProperty(){
		
		Properties prop=new Properties();
		InputStream in=null;
				try {
					in=new FileInputStream("oracle.properties");
					prop.load(in);
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}catch (IOException e){
					e.printStackTrace();
				}finally{
					try {
						in.close();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				return prop;
	}
	
	public static Connection getConnection() throws MobileException {
		Connection con=null;
		Properties prop= JdbcUtil.loadProperty();
		String url=prop.getProperty("oracle.url");
		String driver=prop.getProperty("oracle.driver");
		String user=prop.getProperty("oracle.uname");
		String password=prop.getProperty("oracle.upass");
	try {
		//Class.forName("oracle.jdbc.driver.OracleDriver");
		Class.forName(driver);
		con=DriverManager.getConnection(url,user,password);
		myLogger.info("Connection Established");
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		//e.printStackTrace();
		
	}
	
	//String url1="jdbc:oracle:thin:@10.125.6.62:1521:ORCL11G";
	try{
		con=DriverManager.getConnection(url,user,password);
		myLogger.info("Connected");
}catch(SQLException ex){
	//ex.printStackTrace();
	myLogger.error("Not Connected");
	throw new MobileException("Connection problem");
}
	return con;	
	
}

	/*public static void main(String args[]){
		JdbcUtil j=new JdbcUtil();
		PropertyConfigurator.configure("log4j.properties");
		try{
			j.getConnection();
		}catch(MobileException e){
			e.printStackTrace();
		}
	}*/
}
