package com.cg.ma.ui;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.cg.ma.dto.Mobile;
import com.cg.ma.dto.PurchaseDetails;
import com.cg.ma.execption.MobileException;
import com.cg.ma.execption.PurchaseDetailsException;
import com.cg.ma.service.ImobileServices;
import com.cg.ma.service.IpurchaseServices;
import com.cg.ma.service.MobileServiceImpl;
import com.cg.ma.service.PurchaseServiceImpl;

public class MobileApp {

	private static final Logger myLogger= Logger.getLogger(MobileApp.class);
	public static void main(String[] args){
		
		myLogger.info("Application started");
		System.out.println("Start");
	
	ImobileServices mobileService=new MobileServiceImpl();
	IpurchaseServices purchaseService=new PurchaseServiceImpl();
	int ch=0;
	do{
		printDetail();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your choice:");
		ch=sc.nextInt();
		switch(ch){

		case 1:
			
			String pname="^[A-Z][a-z]{2,19}$";
			System.out.println("Enter your name:");
			String Cname=sc.next();
			try{
				myLogger.info("validation of name started");
			PurchaseServiceImpl.validateName(pname, Cname);
			myLogger.info("validation of name ended");
			}catch(MobileException m1){
				System.out.println(m1.getMessage());
			}
			
		String pmail="^(.+)@(.+)$";
		System.out.println("Enter your email id:");
		String cmail=sc.next();
		try{
			myLogger.info("validation of email id started");
			PurchaseServiceImpl.validateEmail(pmail, cmail);
			myLogger.info("validation of email ended");
		}catch(MobileException m1){
			System.out.println(m1.getMessage());
		}
		
		String pphone="^[7|8|9]{1}[0-9]{9}$";
		System.out.println("Enter your mobile number:");
		String cphone=sc.next();
		try{
			PurchaseServiceImpl.validatePhone(pphone, cphone);
		}catch(MobileException m1){
		System.out.println(m1.getMessage());
		}
		
		String mobileId="^[1]{1}[0-9]{3}$";
		System.out.println("Enter mobile id:");
		String mobileid=sc.next();
		try{
			PurchaseServiceImpl.validateMobileId(mobileId, mobileid);;
		}catch(MobileException m1){
		System.out.println(m1.getMessage());
		}
		
		PurchaseDetails purchase=new PurchaseDetails();
		
		purchase.setCname(Cname);
		purchase.setMailid(cmail);
		purchase.setPhoneno(cphone);
		purchase.setDate(purchase.getDate());
		int mid=Integer.parseInt(mobileid);
		purchase.setMobileid(mid);
			try {
				int rec=purchaseService.addPurchaseDetail(purchase);
				if(rec>0){
					myLogger.info("record is inserted");
				}
			} catch (PurchaseDetailsException | MobileException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
//				myLogger.info(e1);
			}
	
		break;
		case 2:
			List<PurchaseDetails> myPur=null;
			try {
				myPur = purchaseService.showAllPurchaseDetail();
			} catch (MobileException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			for (PurchaseDetails pur : myPur) {
			System.out.println("Purchase Id:"+pur.getPid());
			System.out.println("Customer name:"+pur.getCname());
			System.out.println("Email Id:"+pur.getMailid());
			System.out.println("Phone number:"+pur.getPhoneno());
			System.out.println("Purchase Date:"+pur.getDate());
			System.out.println("Mobile Id:"+pur.getMobileid());
			}

		break;
		
		case 3:
			List<Mobile> myMob=null;
			try {
			myMob=mobileService.showAllMobiles();
			
			}catch(MobileException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			for(Mobile mdetails: myMob){
				System.out.println("Mobile Id:"+mdetails.getMobileid());
				System.out.println("Mobile name:"+mdetails.getName());
				System.out.println("Price:"+mdetails.getPrice());
				System.out.println("Quantity:"+mdetails.getQuantity());
			}
			
			break;
			
		case 4:
			List<Mobile> lmobile=new ArrayList<Mobile>();
			System.out.println("Enter price range");
			double minprice=sc.nextDouble();
			double maxprice=sc.nextDouble();
			
			try{
				myLogger.info("Searching mobiles by range");
				lmobile= mobileService.searchByRanges(minprice, maxprice);
				
			}catch(MobileException e) {
				myLogger.error("Range not found");
				e.printStackTrace();
			}
			for(Mobile mobdetails:lmobile){
				System.out.println(mobdetails);
			}
			
			break;
			
		case 5:
			System.out.println("Enter mobile id:");
			int moid=sc.nextInt();
			try{
				myLogger.info("Deleting mobiles by id");
				System.out.println(mobileService.deleteMobiles(moid));
			
			}catch(MobileException e) {
				// TODO Auto-generated catch block
				myLogger.error("Mobile id not found");
				e.printStackTrace();
			}
			
			break;
		case 6:
			System.out.println("Enter mobile id:");
			int jmobileid=sc.nextInt();
			System.out.println("Enter number of mobiles sold:");
			int soldmobile=sc.nextInt();
			try{
				mobileService.updateQtys(jmobileid, soldmobile);
			}catch(MobileException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		case 7:
			System.exit(0);
			break;
		default:
			System.out.println("Please enter right choice");
			break;
		}
		
		}while(ch!=7);
	myLogger.info("Application Ended");
	}
	private static void printDetail() {
		// TODO Auto-generated method stub
		System.out.println("----------------");
		System.out.println("1.Add Purchase Details");
		System.out.println("2.Show Purchase Details");
		System.out.println("3.Show all mobiles");
		System.out.println("4.search for mobiles");
		System.out.println("5.Remove Mobile");
		System.out.println("6.Update Mobile Quantity");
		System.out.println("7.Exit");
		System.out.println("-------------------");
	}		
}
