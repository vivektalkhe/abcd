package com.cg.ma.dto;

import java.util.Date;

public class PurchaseDetails {

	private int pid;
	private String cname;
	private String mailid;
	private String phoneno;
	private Date date;
	private int mobileid;
	
	public PurchaseDetails() {
		super();
	}

	public PurchaseDetails(int pid, String cname, String mailid,
			String phoneno, Date date, int mobileid) {
		super();
		this.pid = pid;
		this.cname = cname;
		this.mailid = mailid;
		this.phoneno = phoneno;
		this.date = date;
		this.mobileid = mobileid;
	}

	public int getPid() {
		return pid;
	}

	public void setPid(int pid) {
		this.pid = pid;
	}

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public String getMailid() {
		return mailid;
	}

	public void setMailid(String mailid) {
		this.mailid = mailid;
	}

	public String getPhoneno() {
		return phoneno;
	}

	public void setPhoneno(String phoneno) {
		this.phoneno = phoneno;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public int getMobileid() {
		return mobileid;
	}

	public void setMobileid(int mobileid) {
		this.mobileid = mobileid;
	}

	@Override
	public String toString() {
		return "PurchaseDetails [pid=" + pid + ", cname=" + cname + ", mailid="
				+ mailid + ", phoneno=" + phoneno + ", date=" + date
				+ ", mobileid=" + mobileid + "]";
	}
	
	
	
	
	
}
