package com.cg.ma.service;
import java.util.List;

import com.cg.ma.dao.*;
import com.cg.ma.dto.*;
import com.cg.ma.execption.*;

public class MobileServiceImpl implements ImobileServices {

	ImobileDao imobile=new MobileDaoImpl();

	public List<Mobile> showAllMobiles() throws MobileException {
	
		return imobile.showAllMobile();
	}

	public boolean deleteMobiles(int mobileid) throws MobileException {
	
		return imobile.deleteMobile(mobileid);
	}


	public List<Mobile> searchByRanges(double minprice, double maxprice) throws MobileException {
	
		return imobile.searchByRange(minprice, maxprice);
	}
	
	

	@Override
	public boolean updateQtys(int mobileid, int qty) throws MobileException {
		// TODO Auto-generated method stub
		return imobile.updateQty(mobileid, qty);
	}
	
}
