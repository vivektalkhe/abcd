package com.cg.ma.service;

import java.util.List;

import com.cg.ma.dto.Mobile;
import com.cg.ma.execption.MobileException;

public interface ImobileServices {
	
	List<Mobile> showAllMobiles() throws MobileException;
	boolean deleteMobiles(int mobileid) throws MobileException;
	List<Mobile>searchByRanges(double minprice,double maxprice)throws MobileException;
	boolean updateQtys(int mobileid, int qty) throws MobileException;

}
