package com.cg.ma.service;

import java.util.List;

import com.cg.ma.dto.PurchaseDetails;
import com.cg.ma.execption.MobileException;
import com.cg.ma.execption.PurchaseDetailsException;

public interface IpurchaseServices {

	int addPurchaseDetail(PurchaseDetails purchase) throws PurchaseDetailsException, MobileException;
	List<PurchaseDetails> showAllPurchaseDetail() throws MobileException;
	
}
