package com.cg.ma.service;

import java.util.List;
import java.util.regex.Pattern;

import com.cg.ma.dao.IpurchaseDao;
import com.cg.ma.dao.PurchaseDaoImpl;
import com.cg.ma.dto.PurchaseDetails;
import com.cg.ma.execption.MobileException;
import com.cg.ma.execption.PurchaseDetailsException;

public class PurchaseServiceImpl implements IpurchaseServices {

	IpurchaseDao ipurchase=new PurchaseDaoImpl();
	
	public int addPurchaseDetail(PurchaseDetails purchase) throws  MobileException, PurchaseDetailsException{
		return ipurchase.addPurchaseDetails(purchase);
		
	}
	public List<PurchaseDetails> showAllPurchaseDetail() throws MobileException{
		return ipurchase.showAllPurchaseDetails();
	}
	
	public static void validateName(String patt,String name) throws MobileException{
		boolean value=Pattern.matches(patt, name);
		if(!value){
			throw new MobileException("Nmae should be minimum 3 and maxium 10.First letter capital");
			
		}
	}
	
	public static void validatePhone(String patb,String pnames) throws MobileException{
		boolean value=Pattern.matches(patb, pnames);
		if(!value){
			throw new MobileException("Phone number must be 10digits");
			
		}
	}
	
	public static void validateEmail(String patt,String name) throws MobileException{
		boolean value=Pattern.matches(patt, name);
		if(!value){
			throw new MobileException("Please enter valid Email ID");
			
		}
	}
	
	public static void validateMobileId(String patt,String name) throws MobileException{
		boolean value=Pattern.matches(patt, name);
		if(!value){
			throw new MobileException("MobileId should be of 4 digits only");
			
		}
	}
}
