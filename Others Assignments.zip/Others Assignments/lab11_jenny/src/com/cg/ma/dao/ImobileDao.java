package com.cg.ma.dao;

import java.util.List;

import com.cg.ma.dto.Mobile;
import com.cg.ma.execption.MobileException;

public interface ImobileDao {
	
	List<Mobile> showAllMobile() throws MobileException;
	boolean deleteMobile(int mobileid) throws MobileException;
	boolean updateQty(int mobileid,int qty) throws MobileException;
	List<Mobile> searchByRange(double minprice, double maxprice) throws MobileException;

}
