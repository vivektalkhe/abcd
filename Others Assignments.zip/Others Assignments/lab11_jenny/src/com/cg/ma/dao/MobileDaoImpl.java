
package com.cg.ma.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.cg.ma.dto.Mobile;
import com.cg.ma.execption.MobileException;
import com.cg.ma.ui.MobileApp;
import com.cg.ma.util.JdbcUtil;

public class MobileDaoImpl implements ImobileDao {
	private static final Logger myLogger= Logger.getLogger(MobileApp.class);
	Connection con;
	PreparedStatement pst=null;
	public List<Mobile> showAllMobile() throws MobileException {
		con=JdbcUtil.getConnection();
		String query="Select * from mobiles";
		List<Mobile>mList=new ArrayList<Mobile>();
		try {
			pst=con.prepareStatement(query);
			ResultSet rs=pst.executeQuery();
			while(rs.next()){
				int m_id=rs.getInt(1);
				String m_name=rs.getString(2);
				double m_price=rs.getInt(3);
				int m_qty=rs.getInt(4);
				Mobile m=new Mobile();
				m.setMobileid(m_id);
				m.setName(m_name);
				m.setPrice(m_price);
				m.setQuantity(m_qty);
				mList.add(m);
				
			}
			myLogger.info("data displayed successfully");
		} catch (SQLException e) {
			e.printStackTrace();
			myLogger.error("data not found");
			throw new MobileException("Data not found");
		}finally{
			try {
				pst.close();
				con.close();
				
			} catch (SQLException e) {
				
				e.printStackTrace();
				
			}
		}
		return mList;
	
	}


	public boolean deleteMobile(int mobileid) throws MobileException {
		con=JdbcUtil.getConnection();
		int rec=0;
		String query="Delete From mobiles where mobileid=?";
		try {
			pst=con.prepareStatement(query);
			pst.setInt(1, mobileid);
		    rec=pst.executeUpdate();
		    if(rec>0)
		    	return true;
		    myLogger.info("data deleted successfully");
		} catch (SQLException e) {
			e.printStackTrace();
			myLogger.error("data not deleted");
			throw new MobileException("Data not deleted");
		}finally{
			try {
				pst.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return false;	
	}


	public boolean updateQty(int mobileid, int qty) throws MobileException {
		con=JdbcUtil.getConnection();
		int rec=0;
		String query="Update Mobiles SET QUANTITY= QUANTITY-'"+qty+"' Where MOBILEID='"+mobileid+"'";
		try {
			pst=con.prepareStatement(query);
			/*pst.setInt(1, qty);
			pst.setInt(2, mobileid);*/
			pst.executeUpdate();
			if(rec>0)
				return true;
			myLogger.info("Data updated successfully");
		} catch (SQLException e) {
			myLogger.error("Data not updated");
			e.printStackTrace();
			throw new MobileException("Data is not updated");
		}
		return false;
	}


	@Override
	public List<Mobile> searchByRange(double minprice, double maxprice)
			throws MobileException {
		
		con=JdbcUtil.getConnection();
		String query="Select * from mobiles where price >=? AND price<=?";
		List<Mobile>mList=new ArrayList<Mobile>();
		
		try {
			pst=con.prepareStatement(query);
			pst.setDouble(1,minprice);
			pst.setDouble(2,maxprice);
			ResultSet rs=pst.executeQuery();
			while(rs.next()){
				int m_id=rs.getInt(1);
				String m_name=rs.getString(2);
				double m_price=rs.getInt(3);
				int m_qty=rs.getInt(4);
				
				
				
				Mobile m=new Mobile();
				m.setMobileid(m_id);
				m.setName(m_name);
				m.setPrice(m_price);
				m.setQuantity(m_qty);
				mList.add(m);
			}
			myLogger.info("Searching data by range");
		} catch (SQLException e) {
			
			e.printStackTrace();
			myLogger.error("Data not found");
			throw new MobileException("Data not found");
		}finally{
			try{
				pst.close();
				con.close();
			}catch (SQLException e) {
				
				e.printStackTrace();
			}
		}
		
		
		return mList;
	
	}
}
