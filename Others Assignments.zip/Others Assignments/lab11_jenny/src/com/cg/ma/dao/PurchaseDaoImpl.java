package com.cg.ma.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;

import com.cg.ma.dto.PurchaseDetails;
import com.cg.ma.execption.MobileException;
import com.cg.ma.execption.PurchaseDetailsException;
import com.cg.ma.ui.MobileApp;
import com.cg.ma.util.JdbcUtil;

public class PurchaseDaoImpl implements IpurchaseDao  {
	private static final Logger myLogger= Logger.getLogger(MobileApp.class);
	Connection con=null;
	PreparedStatement pst=null;
	
	public int addPurchaseDetails(PurchaseDetails purchase) throws PurchaseDetailsException, MobileException{
		int pId=0;
		String query="INSERT INTO purchasedetails VALUES(?,?,?,?,?,?)";
		try{
		
		con=JdbcUtil.getConnection();
		pst=con.prepareStatement(query);
		pst.setInt(1, getPurchaseId());
		pst.setString(2, purchase.getCname());
		pst.setString(3, purchase.getMailid());
		pst.setString(4,purchase.getPhoneno());
		
		Calendar calendar=Calendar.getInstance();
		java.sql.Date currentDate=new java.sql.Date(calendar.getTime().getTime());
		pst.setDate(5, currentDate);
		pst.setInt(6,purchase.getMobileid() );
		int status=pst.executeUpdate();
		if(status==1)
		System.out.println("Data Inserted Successfully");
		myLogger.info("Data inserted successfully");
		}catch(SQLException e){
			myLogger.error("Data not inserted");
			throw new MobileException("Data not inserted");
		}
		
		return pId;
		
	}


	public List<PurchaseDetails> showAllPurchaseDetails() throws MobileException{
	con=JdbcUtil.getConnection();
	String query="Select * from purchasedetails";
	List<PurchaseDetails>pList=new ArrayList<PurchaseDetails>();
	try {
		pst=con.prepareStatement(query);
		ResultSet rs=pst.executeQuery();
		while(rs.next()){
			int p_id=rs.getInt(1);
			String p_name=rs.getString(2);
			String p_mail=rs.getString(3);
			String p_phone=rs.getString(4);
			Date p_date=rs.getDate(5);
			int p_mid=rs.getInt(6);
			
			
			PurchaseDetails p=new PurchaseDetails();
			p.setPid(p_id);
			p.setCname(p_name);
			p.setMailid(p_mail);
			p.setPhoneno(p_phone);
			p.setDate(p_date);
			p.setMobileid(p_mid);
			pList.add(p);
		}
		myLogger.info("Display purchase details");
	} catch (SQLException e) {
	
		e.printStackTrace();
		myLogger.error("Data not found");
		throw new MobileException("Data not found");
	}finally{
		try{
			pst.close();
			con.close();
		}catch(SQLException e){
			e.printStackTrace();
		}
	}
		return pList;
		
	}

	public static int getPurchaseId(){
		int id=0;
		String query="SELECT purchased.NEXTVAL FROM DUAL";
		Connection conn=null;
		PreparedStatement pstm=null;
		
		try {
			conn=JdbcUtil.getConnection();
			pstm=conn.prepareStatement(query);
			ResultSet res=pstm.executeQuery();
			while(res.next()){
			id=res.getInt(1);
			}
			
		} catch (MobileException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try{
				pstm.close();
				conn.close();
			}catch(SQLException e){
				e.printStackTrace();
			}
		}
		
		return id;
		
	}
}
	
