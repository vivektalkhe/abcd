package com.cg.ma.dao;

import java.util.List;

import com.cg.ma.dto.PurchaseDetails;
import com.cg.ma.execption.MobileException;
import com.cg.ma.execption.PurchaseDetailsException;

public interface IpurchaseDao {

	int addPurchaseDetails(PurchaseDetails purchase) throws PurchaseDetailsException, MobileException;
	List<PurchaseDetails> showAllPurchaseDetails() throws MobileException;
	
}
