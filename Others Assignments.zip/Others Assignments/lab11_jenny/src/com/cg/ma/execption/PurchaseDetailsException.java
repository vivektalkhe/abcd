package com.cg.ma.execption;

public class PurchaseDetailsException extends Exception{

	public PurchaseDetailsException(String msg){
		super(msg);
	}
}
