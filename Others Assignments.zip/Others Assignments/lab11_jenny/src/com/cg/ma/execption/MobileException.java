package com.cg.ma.execption;

public class MobileException extends Exception {
	public MobileException(String msg){
		super(msg);
	}

}
