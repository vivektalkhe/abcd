package com.cg.ma.junittest;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.ma.dao.ImobileDao;
import com.cg.ma.dao.MobileDaoImpl;
import com.cg.ma.execption.MobileException;

public class TestMobileDaoImpl {

	ImobileDao iMobile=null;
	

	@Before
	public void setUp()  {
		iMobile= new MobileDaoImpl();
	}

	@After
	public void tearDown()  {
		iMobile=null;
	}
	
	

	@Test
	public void testShowAll() {
		try {
			assertNotNull((iMobile.showAllMobile()));
		} catch (MobileException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void testdeleteMobile() {
		try {
			assertTrue(iMobile.deleteMobile(1003));
		} catch (MobileException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
	public void testupdateQty() {
		try {
			assertTrue(iMobile.updateQty(1001, 1));
		} catch (MobileException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
	public void testsearchByRange() {
		try {
			assertNotNull(iMobile.searchByRange(5000, 20000));
		} catch (MobileException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
