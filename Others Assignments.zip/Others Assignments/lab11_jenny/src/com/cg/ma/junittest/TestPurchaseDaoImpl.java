package com.cg.ma.junittest;

import static org.junit.Assert.*;

import java.util.Date;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.ma.dao.IpurchaseDao;
import com.cg.ma.dao.PurchaseDaoImpl;
import com.cg.ma.dto.PurchaseDetails;
import com.cg.ma.execption.MobileException;
import com.cg.ma.execption.PurchaseDetailsException;

public class TestPurchaseDaoImpl {
	IpurchaseDao Ipurchase=null;
	PurchaseDetails purc=null;

	@Before
	public void setUp() throws Exception {
		Ipurchase=new PurchaseDaoImpl();
		purc= new PurchaseDetails();
		purc.setCname("Smita");
		purc.setMailid("smp@gml.com");
		purc.setPhoneno("9086745123");
		java.util.Date d1=new java.util.Date();
		Date sysdate=new Date(d1.getTime());
		purc.setDate(sysdate);
		purc.setMobileid(1002);
		
		
	}

	@After
	public void tearDown() throws Exception {
		purc=null;
		Ipurchase=null;
	}

	@Test
	public void testAddPurchaseDetails() {
		try {
			
			assertEquals(22,Ipurchase.addPurchaseDetails(purc));
				//assertNotNull(Ipurchase.addPurchaseDetails(purc));
			} catch (PurchaseDetailsException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 catch (MobileException e) {
			e.printStackTrace();
		}
	}

	

	

	@Test
	public void testShowAllPurchaseDetails() {
		try {
			assertNotNull((Ipurchase.showAllPurchaseDetails()));
		} catch (MobileException e) {
			e.printStackTrace();
		}
	}

}
