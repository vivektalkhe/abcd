package com.capgemini.airspace.service;

import com.capgemini.airspace.bean.UsersBean;
import com.capgemini.airspace.daos.CustomerDao;
import com.capgemini.airspace.daos.CustomerDaoImpl;
import com.capgemini.airspace.exception.CustomerException;

public class CustomerServiceImpl implements CustomerService {

	CustomerDao dao;
	public CustomerServiceImpl() throws CustomerException{
		dao = new CustomerDaoImpl();
	}
	@Override
	public boolean insertUser(UsersBean usr) throws CustomerException {
		System.out.println("kkkk");
		return dao.insertUser(usr);
	}

}
