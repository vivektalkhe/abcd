package com.capgemini.airspace.service;

import com.capgemini.airspace.bean.UsersBean;
import com.capgemini.airspace.exception.CustomerException;

public interface CustomerService {

	 public boolean insertUser(UsersBean usr)throws CustomerException;
}
