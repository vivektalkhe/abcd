package com.capgemini.airspace.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.capgemini.airspace.bean.UsersBean;
import com.capgemini.airspace.exception.CustomerException;
import com.capgemini.airspace.util.JNDIUtil;



public class CustomerDaoImpl implements CustomerDao {
	
	JNDIUtil util;
	public CustomerDaoImpl() throws CustomerException{
		util=new JNDIUtil();
	}

	@Override
	public boolean insertUser(UsersBean usr) throws CustomerException {
		Connection con=null;
		PreparedStatement pst=null;
		
		
		try {
			con=util.getConnection();
			String query="INSERT INTO users VALUES(?,?,?,?)";
			pst=con.prepareStatement(query);
			pst.setString(1, usr.getName());
			pst.setString(2, usr.getUser_name());
			pst.setString(3, usr.getPassword());
			pst.setString(4, usr.getMobile_number());
			
			int c=pst.executeUpdate();
			if(c>0){
				return true;
			}
		} catch (SQLException e) {
			throw new CustomerException("Connection failed",e);
			// TODO Auto-generated catch block
			//e.printStackTrace();
		}finally{
			try {
				if(pst!=null){
					pst.close();
					}
					if(con!=null){
					con.close();
					}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
			}
		}
		
		
		return false;
	}
	

}
