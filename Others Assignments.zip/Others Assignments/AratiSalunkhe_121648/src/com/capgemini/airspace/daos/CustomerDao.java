package com.capgemini.airspace.daos;

import com.capgemini.airspace.bean.UsersBean;
import com.capgemini.airspace.exception.CustomerException;

public interface CustomerDao {
  public boolean insertUser(UsersBean usr)throws CustomerException;
}
