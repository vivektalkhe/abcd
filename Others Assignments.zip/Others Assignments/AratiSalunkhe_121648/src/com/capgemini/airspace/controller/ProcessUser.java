package com.capgemini.airspace.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.capgemini.airspace.bean.UsersBean;
import com.capgemini.airspace.daos.CustomerDaoImpl;
import com.capgemini.airspace.exception.CustomerException;
import com.capgemini.airspace.service.CustomerService;
import com.capgemini.airspace.service.CustomerServiceImpl;



@WebServlet("*.do")
public class ProcessUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   CustomerService service;
   private String nextJsp;
	public void init(ServletConfig config) throws ServletException {
		try {
			service= new CustomerServiceImpl();
		} catch (CustomerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path=request.getServletPath();
		 int avlAmount=700;
		 System.out.println(path);
			switch (path) {
			
			case "/index.do":{
				nextJsp="Register.jsp";
				 System.out.println(nextJsp);
			}break;
			
			case "/reg.do":{
				String name= request.getParameter("name");
				String user_name=request.getParameter("username");
				String password=request.getParameter("password");
				String mobile_number=request.getParameter("mobno");
				
				UsersBean user = new UsersBean(name,user_name,password,mobile_number);
			
				
				
				try {
					System.out.println("inside try");
					boolean success = service.insertUser(user);
					System.out.println("after function call");
					if(success)
					{ HttpSession session=request.getSession(true);
					 session.setAttribute("name", name);
					 session.setAttribute("user_name", user_name);
					 session.setAttribute("password", password);
					 session.setAttribute("mobile_number", mobile_number);
					 session.setAttribute("avlAmount",Integer.toString(avlAmount) );
					 
					 System.out.println(name+user_name+password+mobile_number);
						
					nextJsp="PayBill.jsp";
						
					}
					nextJsp="PayBill.jsp";
				} catch (CustomerException e) {
					// TODO Auto-generated catch block
					//e.printStackTrace();
					nextJsp="error.jsp";
					request.setAttribute("msg", "can not register.");
				}
			}  break;
			case "/withdraw.do":{
				String amountstr=	request.getParameter("amount");
				int amount=Integer.parseInt(amountstr);
				 HttpSession session=request.getSession(false);
				 
				  avlAmount=Integer.parseInt( (String) session.getAttribute("avlAmount"))	 ;
			
				 if(avlAmount>=amount)
				 {
					session.setAttribute("avlAmount", avlAmount-amount);
					nextJsp="success.jsp";
				 }
					
				 else{
						nextJsp="error.jsp";
					request.setAttribute("msg", "not enough balance");
				 }
					
				}
					break;
					
					
			case "/logout.do":{
				 HttpSession session=request.getSession(false);
				 session.invalidate();
				 nextJsp="index.jsp";
			}
	break;
			
			}
		 RequestDispatcher dispatch=request.getRequestDispatcher(nextJsp);
		 dispatch.forward(request, response);
		 
		 
	}

}
