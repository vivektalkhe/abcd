package com.cg.appl.daos;

import java.util.List;

import com.cg.appl.entities.Hotel;
import com.cg.appl.exception.BookingException;

public interface IHotelDao {
	
	boolean isUserAuthenticated(String userName, String password) throws BookingException;
	List<Hotel> showAllHotel() throws BookingException;
	String getUserDetails(String userName) throws BookingException;
	int AddHotel(Hotel hotel) throws BookingException;
	boolean deleteHotel(String hotel_id) throws BookingException;
	boolean updateHotel(Hotel hotel);
	
}
